Begin.Hpcc<-function(signal){
  if (signal=='y' | signal=='Y')
  {
    xyz<<-""
  }
}


Execute.Hpcc<-function(signal){
  if (signal=='y' | signal=='Y')
  {
    xyz2<<-xyz
    xyz<<-""
    fileout<-getwd()
    str<-.libPaths()
    str1<-paste(str,"/REDA/hostsetting.txt",sep="")
    tt<-read.table(str1,sep="\t")
    f1<<-as.character(tt$V1[[1]])
    f2<<-as.character(tt$V1[[2]])
    eclCode<<-xyz2
    hostname<<-f1
    port<<-f2
    
    body<-""
    body <-paste('<?xml version="1.0" encoding="utf-8"?>\
                 <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"\
                 xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"\
                 xmlns="urn:hpccsystems:ws:ecldirect">\
                 <soap:Body>\
                 <RunEclRequest>\
                 <userName>xyz</userName>\
                 <cluster>thor</cluster>\
                 <limitResults>0</limitResults>\
                 <eclText>',eclCode,'</eclText>\
                 <snapshot>test</snapshot>\
                 </RunEclRequest>\
                 </soap:Body>\
                 </soap:Envelope>\n')
    
    headerFields =
      c(Accept = "text/xml",
        Accept = "multipart/*",
        'Content-Type' = "text/xml; charset=utf-8",
        SOAPAction="urn:hpccsystems:ws:ecldirect")
    
    reader = basicTextGatherer()
    handle = getCurlHandle()
    
    ur<-paste("http://",hostname,":",port,"/EclDirect/RunEcl?ver_=1",sep="")
    curlPerform(url = ur,
                httpheader = headerFields,
                postfields = body,
                writefunction = reader$update,
                curl =handle
    )
    status = getCurlInfo( handle )$response.code
    varWu1 <- reader$value()
    newlst<-xmlParse(varWu1)
    layout <- getNodeSet(newlst, "//*[local-name()='results']/text()", namespaces = xmlNamespaceDefinitions(newlst,simplify =
                                                                                                              TRUE))
    colLayout <- layout[[1]]
    layout1<- xmlToList(colLayout)
    contentcsv<<-layout1
    data <- dataresult(contentcsv, downloadPath=fileout)
  }
  
}



# Returns a list of Dataframes for each <Dataset> element of XML.
dataresult<-function (xmlResult, downloadPath) {
  
  # Create an empty list which stores the parsed dataframes.
  
  data <- list() 
  if (missing(xmlResult)) {
    stop("Empty XML String.")
  } 
  else {
    top <- xmlRoot(xmlTreeParse(xmlResult, useInternalNodes = TRUE))
    
    # Get all the nodes "Dataset" nodes
    nodes <- getNodeSet(top, "//Dataset")
    
    for(k in 1:length(nodes)) {  
      
      # Iterate through each element of the get the value.
      plantcat <- xmlSApply(nodes[[k]], function(x) xmlSApply(x, xmlValue))
      #print(class(plantcat))
      
      # Convert to Data Frame
      df <- as.data.frame(plantcat)
      #print(df)
      
      # Transpose of Dataframe. Not needed but just for better presentation
      dfTransposed <- data.frame(t(df),row.names=NULL)
      #print(class(dfTransposed))
      
      #getting the output dataframe in R window
      nodes = getNodeSet(top, "//Dataset")
      datasetNode <- nodes[[k]]
      resultSetName <- xmlGetAttr(datasetNode, "name")
      assign(resultSetName, dfTransposed,envir = .GlobalEnv)
      newdata = data.frame(dfTransposed, stringsAsFactors = FALSE)
      
      # Download the file if "downloadPath" argument is specified
      if(!missing(downloadPath)) {
        # Get the Dataset Attribute name for saving the file
        datasetNode <- nodes[[k]]
        resultSetName <- xmlGetAttr(datasetNode, "name")
        fileName <- paste(resultSetName,".csv", sep = "")
        path <- paste(downloadPath,"/",fileName, sep = "")
        write.table(dfTransposed,file=path,sep=",",row.names=F, col.names = T)
      }
      
      data[[k]] <- list(dfTransposed)
    }  
  }
  
  data
}



hpccCorr<-function(dataframe,fields,method,out.dataframe){
  
  strim<<-function (x)
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recmax :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id; "),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("RECMAX maxtrans (",dataframe,"  L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRMAX:=PROJECT(",dataframe," ,maxtrans(LEFT,COUNTER));"),"\n")
  
  xyz<<-paste(xyz,paste("NumericField :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED4 number;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("STRING field;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("OutDs:=NORMALIZE(DSRMAX,",length(varlst[[1]]),",TRANSFORM(NumericField,SELF.id:=LEFT.id,SELF.number:=COUNTER;
                        SELF.field:=CHOOSE(COUNTER,",str1,");
                        SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  
  xyz<<-paste(xyz,paste("RankableField :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("outDS;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED Pos := 0;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("T :=TABLE(SORT(OutDS,Number,field,Value),RankableField);"),"\n")
  #xyz<<-paste(xyz,paste("T;"),"\n")
  
  xyz<<-paste(xyz,paste("TYPEOF(T) add_rank(T le,UNSIGNED c) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.Pos := c;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("P := PROJECT(T,add_rank(LEFT,COUNTER));"),"\n")
  
  xyz<<-paste(xyz,paste("RS := RECORD"),"\n")
  xyz<<-paste(xyz,paste("Seq := MIN(GROUP,P.pos);"),"\n")
  xyz<<-paste(xyz,paste("P.number;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("Splits := TABLE(P,RS,number,FEW);"),"\n")
  
  xyz<<-paste(xyz,paste("TYPEOF(T) to(P le,Splits ri) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.pos := 1+le.pos - ri.Seq;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("outfile := JOIN(P,Splits,LEFT.number=RIGHT.number,to(LEFT,RIGHT),LOOKUP);"),"\n")
  
  xyz<<-paste(xyz,paste("modeRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("outfile.number;"),"\n")
  xyz<<-paste(xyz,paste("outfile.value;"),"\n")
  xyz<<-paste(xyz,paste("outfile.pos;"),"\n")
  xyz<<-paste(xyz,paste("outfile.field;"),"\n")
  xyz<<-paste(xyz,paste("vals := COUNT(GROUP);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("MTable := TABLE(outfile,modeRec,number,field,value);"),"\n")
  #xyz<<-paste(xyz,paste("MTable;"),"\n")
  
  xyz<<-paste(xyz,paste("newRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("MTable.number;"),"\n")
  xyz<<-paste(xyz,paste("MTable.value;"),"\n")
  xyz<<-paste(xyz,paste("MTable.field;"),"\n")
  xyz<<-paste(xyz,paste("po := (MTable.pos*Mtable.vals + ((Mtable.vals-1)*Mtable.vals/2))/Mtable.vals;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("newTable := TABLE(MTable,newRec);"),"\n")
  #xyz<<-paste(xyz,paste("OUTPUT(newTable,NAMED('TEST'));"),"\n")
  xyz<<-paste(xyz,paste("TestTab := JOIN(outfile,newTable,LEFT.number = RIGHT.number AND LEFT.value = RIGHT.value);"),"\n")
  #xyz<<-paste(xyz,paste("TestTab;"),"\n")
  
  xyz<<-paste(xyz,paste("MyRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("TestTab;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("T1 := TABLE(TestTab,MyRec,id,number,field);"),"\n")
  #xyz<<-paste(xyz,paste("T1;"),"\n")
  
  if (method=='S')
  {
    xyz<<-paste(xyz,paste("SingleForm := Record"),"\n")
    xyz<<-paste(xyz,paste("T1.number;"),"\n")
    xyz<<-paste(xyz,paste("T1.field;"),"\n")
    xyz<<-paste(xyz,paste("REAL8 meanS := AVE(GROUP,T1.po);"),"\n")
    xyz<<-paste(xyz,paste("REAL8 sdS := SQRT(VARIANCE(GROUP,T1.po));"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    
    xyz<<-paste(xyz,paste("single := TABLE(T1,SingleForm,number,field,FEW);"))
    
    xyz<<-paste(xyz,paste("PairRec := RECORD"),"\n")
    xyz<<-paste(xyz,paste("UNSIGNED4 left_number;"),"\n")
    xyz<<-paste(xyz,paste("UNSIGNED4 right_number;"),"\n")
    xyz<<-paste(xyz,paste("STRING left_field;"),"\n")
    xyz<<-paste(xyz,paste("STRING right_field;"),"\n")
    xyz<<-paste(xyz,paste("REAL8   xyS;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    
    xyz<<-paste(xyz,paste("PairRec note_prod(T1 L, T1 R) := TRANSFORM"),"\n")
    xyz<<-paste(xyz,paste("SELF.left_number := L.number;"),"\n")
    xyz<<-paste(xyz,paste("SELF.right_number := R.number;"),"\n")
    xyz<<-paste(xyz,paste("SELF.left_field := L.field;"),"\n")
    xyz<<-paste(xyz,paste("SELF.right_field := R.field;"),"\n")
    xyz<<-paste(xyz,paste("SELF.xyS := L.po*R.po;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    
    xyz<<-paste(xyz,paste("pairs := JOIN(T1,T1,LEFT.id=RIGHT.id AND LEFT.number<![CDATA[<]]>RIGHT.number,note_prod(LEFT,RIGHT));"),"\n")
    
    xyz<<-paste(xyz,paste("PairAccum := RECORD"),"\n")
    xyz<<-paste(xyz,paste("pairs.left_number;"),"\n")
    xyz<<-paste(xyz,paste("pairs.right_number;"),"\n")
    xyz<<-paste(xyz,paste("pairs.left_field;"),"\n")
    xyz<<-paste(xyz,paste("pairs.right_field;"),"\n")
    xyz<<-paste(xyz,paste("e_xyS := SUM(GROUP,pairs.xyS);"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    
    xyz<<-paste(xyz,paste("exys := TABLE(pairs,PairAccum,left_number,right_number,left_field,right_field,FEW);"),"\n")
    xyz<<-paste(xyz,paste("with_x := JOIN(exys,single,LEFT.left_number = RIGHT.number,LOOKUP);"),"\n")
    
    
    xyz<<-paste(xyz,paste("Rec := RECORD"),"\n")
    xyz<<-paste(xyz,paste("UNSIGNED left_number;"),"\n")
    xyz<<-paste(xyz,paste("UNSIGNED right_number;"),"\n")
    xyz<<-paste(xyz,paste("STRING left_field;"),"\n")
    xyz<<-paste(xyz,paste("STRING right_field;"),"\n")
    xyz<<-paste(xyz,paste("REAL8 Spearman;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("n := COUNT(",dataframe,");"),"\n")
    
    xyz<<-paste(xyz,paste("Rec Trans(with_x L, single R) := TRANSFORM"),"\n")
    xyz<<-paste(xyz,paste("SELF.Spearman := (L.e_xyS - n*L.meanS*R.meanS)/(n*L.sdS*R.sdS);"),"\n")
    xyz<<-paste(xyz,paste("SELF := L;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("intjoin:= JOIN(with_x,single,LEFT.right_number=RIGHT.number,Trans(LEFT,RIGHT),LOOKUP);"),"\n")
    xyz<<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(intjoin,{left_field,right_field,Spearman}),left_field,right_field);"),"\n")
    xyz<<-paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep=""),"\n")  
  }
  else 
  {
    if (method=='P')
    {
      xyz<<-paste(xyz,paste("SingleForm := Record"),"\n")
      xyz<<-paste(xyz,paste("T1.number;"),"\n")
      xyz<<-paste(xyz,paste("T1.field;"),"\n")
      xyz<<-paste(xyz,paste("REAL8 meanP := AVE(GROUP,T1.value);"),"\n")
      xyz<<-paste(xyz,paste("REAL8 sdP := SQRT(VARIANCE(GROUP,T1.value));"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      
      xyz<<-paste(xyz,paste("single := TABLE(T1,SingleForm,number,field,FEW);"))
      
      xyz<<-paste(xyz,paste("PairRec := RECORD"),"\n")
      xyz<<-paste(xyz,paste("UNSIGNED4 left_number;"),"\n")
      xyz<<-paste(xyz,paste("UNSIGNED4 right_number;"),"\n")
      xyz<<-paste(xyz,paste("STRING left_field;"),"\n")
      xyz<<-paste(xyz,paste("STRING right_field;"),"\n")
      xyz<<-paste(xyz,paste("REAL8   xyP;"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      
      xyz<<-paste(xyz,paste("PairRec note_prod(T1 L, T1 R) := TRANSFORM"),"\n")
      xyz<<-paste(xyz,paste("SELF.left_number := L.number;"),"\n")
      xyz<<-paste(xyz,paste("SELF.right_number := R.number;"),"\n")
      xyz<<-paste(xyz,paste("SELF.left_field := L.field;"),"\n")
      xyz<<-paste(xyz,paste("SELF.right_field := R.field;"),"\n")
      xyz<<-paste(xyz,paste("SELF.xyP := L.value*R.value;"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      
      xyz<<-paste(xyz,paste("pairs := JOIN(T1,T1,LEFT.id=RIGHT.id AND LEFT.number<![CDATA[<]]>RIGHT.number,note_prod(LEFT,RIGHT));"),"\n")
      
      xyz<<-paste(xyz,paste("PairAccum := RECORD"),"\n")
      xyz<<-paste(xyz,paste("pairs.left_number;"),"\n")
      xyz<<-paste(xyz,paste("pairs.right_number;"),"\n")
      xyz<<-paste(xyz,paste("pairs.left_field;"),"\n")
      xyz<<-paste(xyz,paste("pairs.right_field;"),"\n")
      xyz<<-paste(xyz,paste("e_xyP := SUM(GROUP,pairs.xyP);"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      
      xyz<<-paste(xyz,paste("exys := TABLE(pairs,PairAccum,left_number,right_number,left_field,right_field,FEW);"),"\n")
      xyz<<-paste(xyz,paste("with_x := JOIN(exys,single,LEFT.left_number = RIGHT.number,LOOKUP);"),"\n")
      
      xyz<<-paste(xyz,paste("Rec := RECORD"),"\n")
      xyz<<-paste(xyz,paste("UNSIGNED left_number;"),"\n")
      xyz<<-paste(xyz,paste("UNSIGNED right_number;"),"\n")
      xyz<<-paste(xyz,paste("STRING left_field;"),"\n")
      xyz<<-paste(xyz,paste("STRING right_field;"),"\n")
      xyz<<-paste(xyz,paste("REAL8 Pearson;"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      xyz<<-paste(xyz,paste("n := COUNT(",dataframe,");"),"\n")
      
      xyz<<-paste(xyz,paste("Rec Trans(with_x L, single R) := TRANSFORM"),"\n")
      xyz<<-paste(xyz,paste("SELF.Pearson := (L.e_xyP - n*L.meanP*R.meanP)/(n*L.sdP*R.sdP);"),"\n")
      xyz<<-paste(xyz,paste("SELF := L;"),"\n")
      xyz<<-paste(xyz,paste("END;"),"\n")
      xyz<<-paste(xyz,paste("intjoin:= JOIN(with_x,single,LEFT.right_number=RIGHT.number,Trans(LEFT,RIGHT),LOOKUP);"),"\n")
      xyz<<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(intjoin,{left_field,right_field,Pearson}),left_field,right_field);"),"\n")
      xyz<<-paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep=""),"\n")  
      
    }
    else
    {
      stop("no proper method")  
    }
  }
}

hpccData.layout<-function(logicalfilename,out.struct){
  body<-""
  body <-paste('<?xml version="1.0" encoding="utf-8"?>\
               <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"\
               xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"\
               xmlns="urn:hpccsystems:ws:wsdfu">\
               <soap:Body>\
               <DFUInfoRequest>\
               <Name>',logicalfilename,'</Name>\
               </DFUInfoRequest>\
               </soap:Body>\
               </soap:Envelope>\n')
  
  headerFields =
    c(Accept = "text/xml",
      Accept = "multipart/*",
      'Content-Type' = "text/xml; charset=utf-8",
      SOAPAction="urn:hpccsystems:ws:wsdfu")
  
  reader = basicTextGatherer()
  handle = getCurlHandle()
  
  fileout<-getwd()
  str<-.libPaths()
  str1<-paste(str,"/rtoHpcc/hostsetting.txt",sep="")
  tt<-read.table(str1,sep="\t")
  f1<-as.character(tt$V1[[1]])
  f2<-as.character(tt$V1[[2]])
  ur<-paste("http://",f1,":",f2,"/WsDfu?ver_=1.2",sep="")
  curlPerform(url = ur,
              httpheader = headerFields,
              postfields = body,
              writefunction = reader$update,
              curl =handle
  )
  #status = getCurlInfo( handle )$response.code
  
  sResponse <- reader$value()
  responseXml <- xmlParse(sResponse)
  layout <- getNodeSet(responseXml, "//*[local-name()='Ecl']/text()", namespaces = xmlNamespaceDefinitions(responseXml,simplify =
                                                                                                             TRUE))
  colLayout <- layout[[1]]
  assign(paste(out.struct),xmlToList(colLayout,addAttributes=TRUE), envir = .GlobalEnv)
}


hpccFreq<-function(dataframe,fields,sortorder=NULL,out.dataframe){
  
  
  strim<<-function (x)
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)
  }
  
  semitrim<<-function(x)
  {
    gsub(";","",x)
  }
  
  ## split layout var types####
  ## respective int and string combos## 
  semiperson<-semitrim(personout)
  split_val<<- strsplit(semiperson, "\n")
  int<-grep("integer",split_val[[1]])
  rl<-grep("real",split_val[[1]])
  una<-grep("unasign",split_val[[1]])
  dcml<-grep("decimal",split_val[[1]])
  dbl<-grep("double",split_val[[1]])
  real_int<<-c(split_val[[1]][int],split_val[[1]][rl],split_val[[1]][una],split_val[[1]][dcml],split_val[[1]][dbl])
  str<-grep("string",split_val[[1]])
  uni<-grep("unicode",split_val[[1]])
  str_uni<<-c(split_val[[1]][str],split_val[[1]][uni])
  
  num_new<<-NA
  char_new<<-NA
  
  ##split the var string###  
  field_splt <<- strsplit(fields, ",")
  for (i in 1:length(field_splt[[1]]))
  {
    j<-strim(field_splt[[1]][i])
    
    if (any(grepl(j,real_int)))
      num_new[i]<<-j
    else
      char_new[i]<<-j      
  }
  
  num_new<-na.omit(num_new)
  char_new<-na.omit(char_new)
  
  is.not.na <- function(x) !is.na(x) 
  is.not.null <- function(x) !is.null(x)
  
  if (is.not.na(char_new[1]))
  {
    varlst<<-strsplit(char_new, ",")
    str1<-NULL
    str2<-NULL
    for (i in 1:length(char_new))
    {
      k<-strim(varlst[[i]][1])
      h<<-strsplit(k," ")
      if (i > 1)
      {
        charh<-paste("'",h[[1]][1],"'",sep="")
        str1<-strim(paste(str1,charh,sep=","))
        hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
        str2<-strim(paste(str2,hh,sep=","))
      }
      else
      {
        charh<-paste("'",h[[1]][1],"'",sep="")
        str1<-strim(paste(str1,charh))
        hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
        str2<-strim(paste(str2,hh))
      }
    }
    
    xyz<<-paste(xyz,paste("NumericField :=RECORD"),"\n")
    xyz<<-paste(xyz,paste("STRING field;"),"\n")
    xyz<<-paste(xyz,paste("STRING value;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("OutDSStr := NORMALIZE(",dataframe,",",length(varlst),",TRANSFORM(NumericField,SELF.field:=CHOOSE(COUNTER,",str1,");
                          SELF.value:=CHOOSE(COUNTER,",str2,")));",sep=""),"\n")
    xyz<<-paste(xyz,paste("FreqRecStr:=RECORD"),"\n")
    xyz<<-paste(xyz,paste("OutDSStr.field;"),"\n")     
    xyz<<-paste(xyz,paste("OutDSStr.value;"),"\n")
    xyz<<-paste(xyz,paste("INTEGER frequency:=COUNT(GROUP);"),"\n")
    xyz<<-paste(xyz,paste("REAL8 Percent:=(COUNT(GROUP)/COUNT(",dataframe,"))*100;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("Frequency1 := TABLE(OutDSStr,FreqRecStr,field,value,MERGE);"),"\n")
  } 
  
  
  if (is.not.na(num_new[1]))
  {
    
    varlst<<-strsplit(num_new, ",")
    str1<-NULL
    str2<-NULL
    for (i in 1:length(num_new))
    {
      k<-strim(varlst[[i]][1])
      h<<-strsplit(k," ")
      if (i > 1)
      {
        charh<-paste("'",h[[1]][1],"'",sep="")
        str1<-strim(paste(str1,charh,sep=","))
        hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
        str2<-strim(paste(str2,hh,sep=","))
      }
      else
      {
        charh<-paste("'",h[[1]][1],"'",sep="")
        str1<-strim(paste(str1,charh))
        hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
        str2<-strim(paste(str2,hh))
      }
    }
    xyz<<-paste(xyz,paste("NumField:=RECORD"),"\n")
    xyz<<-paste(xyz,paste("STRING field;"),"\n")
    xyz<<-paste(xyz,paste("REAL value;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("OutDSNum := NORMALIZE(",dataframe,",",length(varlst),",TRANSFORM(NumField,SELF.field:=CHOOSE(COUNTER,",str1,");
                          SELF.value:=CHOOSE(COUNTER,",str2,")));",sep=""),"\n")
    xyz<<-paste(xyz,paste("FreqRecNum:=RECORD"),"\n")
    xyz<<-paste(xyz,paste("OutDSNum.field;"),"\n")
    xyz<<-paste(xyz,paste("OutDSNum.value;"),"\n")
    xyz<<-paste(xyz,paste("INTEGER frequency:=COUNT(GROUP);"),"\n")
    xyz<<-paste(xyz,paste("REAL8 Percent:=(COUNT(GROUP)/COUNT(",dataframe,"))*100;"),"\n")
    xyz<<-paste(xyz,paste("END;"),"\n")
    xyz<<-paste(xyz,paste("Frequency2 := TABLE(OutDSNum,FreqRecNum,field,value,MERGE);"),"\n")  
  }
  
  
  
  if (is.not.null(sortorder))
  {
    if (sortorder=='ASC')
      d<<-'+'
    else
      d<<-'-'
    
    for (i in 1:length(field_splt[[1]]))
    {
      
      ind_var<<-strim(field_splt[[1]][i])
      if(any(grepl(ind_var,char_new)))
      {
        freq='frequency1'
      }
      else
      {
        freq='frequency2'
      }
      
      dd<-grep(ind_var,split_val[[1]])
      vartype<<-strim(split_val[[1]][dd])
      xyz<<-paste(xyz,paste(out.dataframe,"_",ind_var,":=SORT(TABLE(",freq,"(field ='",ind_var,"'),{",vartype,                
                            ":=value;frequency;Percent}),",d,ind_var,");",sep=""),"\n")
      xyz<<-paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,"_",ind_var,",20),named('",ind_var,"'));",sep=""),"\n")
    } 
  }
  else
  {
    for (i in 1:length(field_splt[[1]]))
    {  
      ind_var<<-strim(field_splt[[1]][i])
      if(any(grepl(ind_var,char_new)))
      {
        freq='frequency1'
      }
      else
      {
        freq='frequency2'
      }
      
      dd<-grep(ind_var,split_val[[1]])
      vartype<<-strim(split_val[[1]][dd])
      xyz<<-paste(xyz,paste(out.dataframe,"_",ind_var,":=SORT(TABLE(",freq,"(field ='",ind_var,"'),{",vartype,                
                            ":=value;frequency;Percent}),",'+',ind_var,");",sep=""),"\n")
      xyz<<-paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,"_",ind_var,",20),named('",ind_var,"'));",sep=""),"\n")
    }
  }
  
}


hpccMax<-function(dataframe,fields,out.dataframe){
  
  trim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recmax :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("RECMAX maxtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRMAX:=PROJECT(",dataframe,",maxtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRMAX;"),"\n")
  xyz<<-paste(xyz,paste("MaxField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMax:=NORMALIZE(DSRMAX,",length(varlst[[1]]),",TRANSFORM(MaxField,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsMax;"),"\n")
  xyz<<-paste(xyz,paste("SinglemaxField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsMax.Field;"),"\n")
  xyz<<-paste(xyz,paste("Maxval := MAX(GROUP,OutDsMax.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsMax,SinglemaxField,Field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
}


hpccMean<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recavg :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recavg avgtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRAVG:=PROJECT(",dataframe,",avgtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRAVG;"),"\n")
  xyz<<-paste(xyz,paste("NumAvgField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsavg:=NORMALIZE(DSRAVG,",length(varlst[[1]]),",TRANSFORM
                        (NumAvgField,SELF.id:=LEFT.id,SELF.field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsavg;"),"\n")
  xyz<<-paste(xyz,paste("SingleavgField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsavg.field;"),"\n")
  xyz<<-paste(xyz,paste("Mean := AVE(GROUP,OutDsavg.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsavg,SingleavgField,field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
}


hpccMedian<-function(dataframe,fields,out.dataframe){
  
  trim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recmax :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("RECMAX maxtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("DSRMAX:=PROJECT(",dataframe,",maxtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRMAX;"),"\n")
  
  xyz<<-paste(xyz,paste("MaxField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED4 number;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMed:=NORMALIZE(DSRMAX,",length(varlst[[1]]),",TRANSFORM(MaxField,SELF.id:=LEFT.id,SELF.number:=COUNTER;SELF.Field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  
  xyz<<-paste(xyz,paste("RankableField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsMed;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED Pos := 0;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("T := TABLE(SORT(OutDsMed,Number,field,Value),RankableField);"),"\n")
  
  xyz<<-paste(xyz,paste("TYPEOF(T) add_rank(T le,UNSIGNED c) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.Pos := c;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("P := PROJECT(T,add_rank(LEFT,COUNTER));"),"\n")  
  xyz<<-paste(xyz,paste("RS := RECORD"),"\n")
  xyz<<-paste(xyz,paste("Seq := MIN(GROUP,P.pos);"),"\n")
  xyz<<-paste(xyz,paste("P.number;"),"\n")
  xyz<<-paste(xyz,paste("P.field;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("Splits := TABLE(P,RS,number,field,FEW);"),"\n")
  xyz<<-paste(xyz,paste("TYPEOF(T) to(P le,Splits ri) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.pos := 1+le.pos - ri.Seq;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("outfile := JOIN(P,Splits,LEFT.number=RIGHT.number,to(LEFT,RIGHT),LOOKUP);"),"\n")
  xyz<<-paste(xyz,paste("n := COUNT(DSRMAX);"),"\n")
  
  xyz<<-paste(xyz,paste("MedRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("outfile.number;"),"\n")
  xyz<<-paste(xyz,paste("SET OF UNSIGNED poso := IF(n%2=0,[n/2,n/2 + 1],[(n+1)/2]);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("MyT := TABLE(outfile,MedRec,field,number);"),"\n")
  xyz<<-paste(xyz,paste("MedianValues:=JOIN(outfile,MyT,LEFT.number=RIGHT.number AND LEFT.pos IN RIGHT.poso);"),"\n")
  xyz<<-paste(xyz,paste("medianRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("MedianValues.field;"),"\n")
  xyz<<-paste(xyz,paste("Median := AVE(GROUP, MedianValues.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(MedianValues,medianRec,field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
}


hpccMin<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recmin :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recmin mintrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRMIN:=PROJECT(",dataframe,",mintrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSR;"),"\n")
  xyz<<-paste(xyz,paste("NumField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMin:=NORMALIZE(DSRMIN,",length(varlst[[1]]),",TRANSFORM(NumField,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsMin;"),"\n")
  xyz<<-paste(xyz,paste("SingleField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDSMin.Field;"),"\n")
  xyz<<-paste(xyz,paste("Minval := MIN(GROUP,OutDSMin.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDSMin,SingleField,Field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
}


hpccMode<-function(dataframe,fields,out.dataframe){
  
  trim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  
  xyz<<-paste(xyz,paste("recmax :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("RECMAX maxtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("DSRMAX:=PROJECT(",dataframe,",maxtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRMAX;"),"\n")
  
  xyz<<-paste(xyz,paste("MaxField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED4 number;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMode:=NORMALIZE(DSRMAX,",length(varlst[[1]]),",TRANSFORM(MaxField,SELF.id:=LEFT.id,SELF.number:=COUNTER;
                        SELF.Field:=CHOOSE(COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  
  xyz<<-paste(xyz,paste("RankableField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsMode;"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED Pos := 0;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("T := TABLE(SORT(OutDsMode,Number,field,Value),RankableField);"),"\n")
  
  xyz<<-paste(xyz,paste("TYPEOF(T) add_rank(T le,UNSIGNED c) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.Pos := c;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("P := PROJECT(T,add_rank(LEFT,COUNTER));"),"\n")  
  xyz<<-paste(xyz,paste("RS := RECORD"),"\n")
  xyz<<-paste(xyz,paste("Seq := MIN(GROUP,P.pos);"),"\n")
  xyz<<-paste(xyz,paste("P.number;"),"\n")
  xyz<<-paste(xyz,paste("P.field;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("Splits := TABLE(P,RS,number,field,FEW);"),"\n")
  xyz<<-paste(xyz,paste("TYPEOF(T) to(P le,Splits ri) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.pos := 1+le.pos - ri.Seq;"),"\n")
  xyz<<-paste(xyz,paste("SELF := le;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("outfile := JOIN(P,Splits,LEFT.number=RIGHT.number,to(LEFT,RIGHT),LOOKUP);"),"\n")
  xyz<<-paste(xyz,paste("n := COUNT(OutDsMode);"),"\n")
  
  xyz<<-paste(xyz,paste("ModeRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("outfile.number;"),"\n")
  xyz<<-paste(xyz,paste("outfile.value;"),"\n")
  xyz<<-paste(xyz,paste("outfile.field;"),"\n")
  xyz<<-paste(xyz,paste("outfile.pos;"),"\n")
  xyz<<-paste(xyz,paste("vals := COUNT(GROUP);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("MTable := TABLE(outfile,modeRec,number,field,value);"),"\n")
  xyz<<-paste(xyz,paste("newRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("MTable.number;"),"\n")
  xyz<<-paste(xyz,paste("MTable.value;"),"\n")
  xyz<<-paste(xyz,paste("MTable.field;"),"\n")
  xyz<<-paste(xyz,paste("po := (MTable.pos*Mtable.vals + ((Mtable.vals-1)*Mtable.vals/2))/Mtable.vals;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste("newTable := TABLE(MTable,newRec);"),"\n")
  xyz<<-paste(xyz,paste("modT := TABLE(MTable,{number,cnt:=MAX(GROUP,vals)},number);"),"\n")
  xyz<<-paste(xyz,paste("Modes:=JOIN(MTable,ModT,LEFT.number=RIGHT.number AND LEFT.vals=RIGHT.cnt);"),"\n")
  xyz<<-paste(xyz,paste("ModesRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("field := Modes.field;"),"\n")
  xyz<<-paste(xyz,paste("mode := Modes.value;"),"\n")
  xyz<<-paste(xyz,paste("Modes.cnt;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(Modes,ModesRec);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
}


hpccRand<-function(dataframe,out.dataframe){
  
  
  strim<<-function (x)
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)
  } 
  
  xyz<<-paste(xyz,paste("MyOutRec := RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED DECIMAL8_8 rand;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("end;"),"\n")
  
  xyz<<-paste(xyz,paste("MyOutRec MyTrans(",dataframe," L, UNSIGNED4 C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.rand := C/4294967295;"),"\n")
  xyz<<-paste(xyz,paste("SELF := L;"),"\n")
  xyz<<-paste(xyz,paste("end;"),"\n")
  
  
  xyz<<-paste(xyz,paste(out.dataframe,":= project(",dataframe,",MyTrans(LEFT, RANDOM()));"),"\n")
  xyz<<-paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),NAMED('",out.dataframe,"'));",sep=""),"\n")
  
}

hpccRead.Data<-function(logicalfilename,layoutname,in.struct,filetype,out.dataframe){
  strim<<-function (x){
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)
  }
  is.not.null <- function(x) ! is.null(x)
  if(missing(logicalfilename))
  {
    stop("no logicalfinlename")
  }
  else
  {
    xyz<<-""
    strd<-strim(paste(layoutname,":=",in.struct,sep=" "))
    xyz<-strim(paste(strd,sep=""))
    str1<-strim(paste(logicalfilename,"'",sep=""))
    str2<-strim(paste(str1,",",layoutname,",",filetype,");",sep=""))
    xyz<-strim(paste(xyz,paste(out.dataframe,":=DATASET('~",str2,sep="")))
    xyz<<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
    
  }
}


hpccSd<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe)
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }
    
  }
  xyz<<-paste(xyz,paste("recsd :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recsd sdtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRSD:=PROJECT(",dataframe,",sdtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRSD;"),"\n")
  xyz<<-paste(xyz,paste("NumSdField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsSd:=NORMALIZE(DSRSD,",length(varlst[[1]]),",TRANSFORM(NumSdField,SELF.id:=LEFT.id,SELF.field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsSd;"),"\n")
  xyz<<-paste(xyz,paste("SingleSdField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsSd.field;"),"\n")
  xyz<<-paste(xyz,paste("Sd := SQRT(VARIANCE(GROUP,OutDsSd.value));"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsSd,SingleSdField,field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(CHOOSEN(",out.dataframe,",20),named('",out.dataframe,"'));",sep="")))
}


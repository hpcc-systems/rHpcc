hpcc.get.name <- function() {
	noOfEclVariables <<- noOfEclVariables +1
	name <- paste('r2EclVariable',noOfEclVariables,sep='')
	return(name)
}


hpcc.begin <-function (import='') {
	hpccSessionVariables <<- matrix(data=numeric(0),ncol=2)
	hpccDownloadedFiles <<- matrix(data=numeric(0),ncol=2)
	eclQuery <<- ""
	noOfEclVariables <<- 0
}


hpcc.get.url <- function(execute=TRUE) {
	fileout<-getwd()
	libFolderPaths<-.libPaths()
	hostpropertiesPath <- NULL
	str1<-''
	packageName <- getPackageName()
	i<-0
	config <-NULL
	if(length(libFolderPaths) > 0) {
		for(i in 1 : length(libFolderPaths)) {
			str1 <- paste(libFolderPaths[i], "/", packageName, "/RConfig.yml", sep="");
			if(file.exists(str1)) {
				config <- yaml.load_file(str1)
				break
			}
		}
	}
	if(is.null(config))
		stop("Can't fing RConfig.yml")
	ecl_direct <- config$hpcchost$ecl_direct
	hostFileName <- config$hpcchost$filename
	str1 <- paste(libFolderPaths[i], "/", packageName, "/", hostFileName, sep="");
	if(file.exists(str1)) {
		hostpropertiesPath <- str1
	}
	if(is.null(hostpropertiesPath)) {
		print(paste('Host Properties File is missing in ',libFolderPaths))
		inp <- readline(prompt="Do you want to input the details here(Y/N) : ")
		if(inp=='Y') {
			hpccHostName <<- readline(prompt="Enter the Host Adress(Ex : 111.111.11.11) : ")
			hpccProtocol <<- readline(prompt="Enter the Protocol (http/https) : ")
			if(hpccProtocol=='')
				hpccProtocol <<- 'http'
			hpccPort <<- readline(prompt="Enter the Port(Ex : 8010) : ")
			hpccUsername <<- readline('Enter the username : ')
			hpccClustername <<- readline("Enter the Cluster Name : ")
			
			hpcc <- list(hpcc=list(hostName = hpccHostName,protocol = hpccProtocol,port_thor=hpccPort,username=hpccUsername,clustername=hpccClustername))
			hpcc <- as.yaml(hpcc)
			file.create(str1)
			fileCon <- file(str1)
			writeLines(hpcc, fileCon)
			close(fileCon)			
			
		}
		else {
			return()
		}
	}
	else {
		obj_hpccHost_prop <- yaml.load_file(hostpropertiesPath)
		hpccHostName <<- obj_hpccHost_prop$hpcc$host
		hpccProtocol <<- obj_hpccHost_prop$hpcc$protocol
		hpccPort <<- obj_hpccHost_prop$hpcc$port_thor
		hpccUsername <<- obj_hpccHost_prop$hpcc$username
		hpccClustername <<- obj_hpccHost_prop$hpcc$clustername
		
	}
	hpccdfu_service <<- config$hpcchost$dfu_service
	ecl_direct <<- ecl_direct
	
	uUrl <<- paste(hpccProtocol,'://',hpccHostName,":",hpccPort,"/", hpccdfu_service, sep="")
	return(uUrl)
	
}


hpcc.data.layout <- function(logicalfilename) {
		uUrl <- hpcc.get.url()
		out.struct <- ""
		body <- paste('<?xml version="1.0" encoding="utf-8"?>
					  <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"
					  xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"
					  xmlns="urn:hpccsystems:ws:wsdfu">
					  <soap:Body>
					  <DFUInfoRequest>
					  <Name>',logicalfilename,'</Name>
					  </DFUInfoRequest>
					  </soap:Body>
					  </soap:Envelope>')
		
		headerFields =
			c(Accept = "text/xml",
			  Accept = "multipart/*",
			  'Content-Type' = "text/xml; charset=utf-8",
			  SOAPAction="urn:hpccsystems:ws:wsdfu")
		
		reader = basicTextGatherer()
		
		handle = getCurlHandle()
		curlPerform(url = uUrl,
					httpheader = headerFields,
					postfields = body,
					writefunction = reader$update,
					curl = handle
		)
		
		status = getCurlInfo( handle )$response.code
		if(status >= 200 && status <= 300) {
			sResponse <- reader$value()
			responseXml <- xmlParse(sResponse)
			
			layout <- getNodeSet(responseXml, "//*[local-name()='Ecl']/text()", 
								 namespaces = xmlNamespaceDefinitions(responseXml,simplify = TRUE))
			if(length(layout) > 0) {
				colLayout <- layout[[1]]
				out.struct <- xmlToList(colLayout,addAttributes=TRUE)
			}
		}
		
		out.struct
}


hpcc.dataset <- function(logicalfilename,filetype, inlineData, layoutname) {
	outputDataset <- ""
	outputDatasetName <- hpcc.get.name()
	if(!missing(logicalfilename)) {
		recordLayout <- hpcc.data.layout(logicalfilename)
		data <- sprintf("'~%s'", logicalfilename)
		recLayoutName <- hpcc.get.name()
		eclQuery <- sprintf("%s %s := %s",eclQuery,recLayoutName, recordLayout)
		data <- sprintf("%s, %s, %s", data,recLayoutName,filetype)
	} else if (!missing(inlineData) & !missing(layoutname)) {
		functionArgs <- (as.list(match.call()))
		eclQuery <- sprintf("%s %s := %s;",eclQuery, as.character(functionArgs$layoutname), layoutname)
		data <- sprintf("[ %s ], %s", inlineData, as.character(functionArgs$layoutname))
	} else {
		stop('Arguments are not proper')
	}
	outputDataset <- sprintf("%s := DATASET(%s);\n",outputDatasetName, data)
	eclQuery <- sprintf("%s %s",eclQuery,outputDataset)
	hpcc.submit(eclQuery)
	return(outputDatasetName)
}



hpcc.execute <-
	function (signal) {
		if(is.null(uUrl))
			stop('Please start HPCC using the function - hpcc.begin()')
		eclCode <- eclQuery
		eclQuery <<- ""
		fileout <- getwd()
		str <- .libPaths()
		eclCode <- paste('<![CDATA[',eclCode,']]>')
		body <- ""
		body <-paste('<?xml version="1.0" encoding="utf-8"?>\
					 <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"\
					 xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"\
					 xmlns="urn:hpccsystems:ws:ecldirect">\
					 <soap:Body>\
					 <RunEclRequest>\
					 <userName>',hpccUsername,'</userName>\
					 <cluster>',hpccClustername,'</cluster>\
					 <limitResults>0</limitResults>\
					 <eclText>',eclCode,'</eclText>\
					 <snapshot/>\
					 </RunEclRequest>\
					 </soap:Body>\
					 </soap:Envelope>\n', sep="")
		eclCode <<- eclCode
		
		headerFields = c(Accept = "text/xml", Accept = "multipart/*", 
						 `Content-Type` = "text/xml; charset=utf-8", SOAPAction = "urn:hpccsystems:ws:ecldirect")
		reader = basicTextGatherer()
		
		handle = getCurlHandle()
		uUrlforEx <- paste(hpccProtocol,'://',hpccHostName,":",hpccPort,"/",ecl_direct,"/RunEcl?ver_=1", sep="")
		
		ur <- uUrlforEx
		curlPerform(url = ur, httpheader = headerFields, postfields = body, 
					writefunction = reader$update, curl = handle)
		status = getCurlInfo(handle)$response.code
		varWu1 <- reader$value()
		newlst <- xmlParse(varWu1)
		layout <- getNodeSet(newlst, "//*[local-name()='results']/text()", 
							 namespaces = xmlNamespaceDefinitions(newlst, simplify = TRUE))
		
		colLayout <- layout[[1]]
# 		print(colLayout)
		layout1 <- xmlToList(colLayout)
# 		print(layout1)
		hpccData <<- data.result(layout1)
# 		hpccData
		hpcc.showFilesToDownload()
		if(length(hpccData)==0)
			return()
		i <- readline('Do you want to plot any graph (Y/N): ')
		if(i!='Y') {
			return('Bye')
		}
		for(i in 1:length(hpccData)) {
			print(paste(i,names(hpccData[[i]]),sep=' '))
		}
		a <- readline('Choose the dataset to plot : ')
		a <- as.numeric(a)
		print("1. Histogram")
		print("2. Scatter Plot")
		graphtype <- readline('Choose the graph to plot : ')
		graphtype <- as.numeric(graphtype)
		lis <- as.list(names(hpccData[[a]][[1]]))
		for(i in 1:length(lis)) {
			print(paste(i,lis[[i]][[1]],sep=' '))
		}
		x <- readline('Input the variable to plot as X-axis :' )
		x <- as.numeric(x)
		y <- readline('Input the variable to plot as Y-axis :' )
		y <- as.numeric(y)
		
		if(graphtype==2) {
			plot(as.numeric(hpccData[[a]][[1]][[x]]),as.numeric(hpccData[[a]][[1]][[y]]),xlab=lis[[x]][[1]],ylab=lis[[y]][[1]])
		}
		if(graphtype==1) {
			hist(as.numeric(hpccData[[1]][[a]][[x]]),as.numeric(hpccData[[1]][[a]][[y]]),xlab=lis[[x]][[1]],ylab=lis[[y]][[1]])
		}		
	}

data.result <- function (xmlResult, downloadPath, format) {
	data
	if (missing(xmlResult)) {
		stop("Empty XML String.")
	}
	else {
		
		# Create an empty list which stores the parsed dataframes.
		
		data <- list() 
		if (missing(xmlResult)) {
			stop("Empty XML String.")
		} 
		else {
			top <- xmlRoot(xmlTreeParse(xmlResult, useInternalNodes = TRUE))
			
			# Get all the nodes "Dataset" nodes
			nodes <- getNodeSet(top, "//Dataset")
			for(k in 1:length(nodes)) {
				
				if(length(nodes)==0)
					return()
				
				# Iterate through each element of the get the value.
				plantcat <- xmlSApply(nodes[[k]], function(x) xmlSApply(x, xmlValue))
				#print(class(plantcat))
				
				# Convert to Data Frame
				df <- as.data.frame(plantcat)
				#print(df)
				
				# Transpose of Dataframe. Not needed but just for better presentation
				dfTransposed <- data.frame(t(df),row.names=NULL)
				#print(class(dfTransposed))
				
				#getting the output dataframe in R window
				nodes = getNodeSet(top, "//Dataset")
				datasetNode <- nodes[[k]]
				resultSetName <- xmlGetAttr(datasetNode, "name")
				assign(resultSetName, dfTransposed,envir = .GlobalEnv)
				newdata = data.frame(dfTransposed, stringsAsFactors = FALSE)
				
				# Download the file if "downloadPath" argument is specified
				if(!missing(downloadPath)) {
					# Get the Dataset Attribute name for saving the file
					datasetNode <- nodes[[k]]
					resultSetName <- xmlGetAttr(datasetNode, "name")
					fileName <- paste(resultSetName,".csv", sep = "")
					path <- paste(downloadPath,"/",fileName, sep = "")
					write.table(dfTransposed,file=path,sep=",",row.names=F, col.names = T)
				}
				
				data[[k]] <- list(dfTransposed)
				names(data[[k]]) <- resultSetName
			}
		}
		
		data
	}
}



hpcc.output <- function (out.dataframe,noOfRecordsNeed,download=FALSE) {
	functionArgs <- (as.list(match.call()))
	outX <- as.character(functionArgs$out.dataframe)
	out <- paste("OUTPUT(", out.dataframe,"[1..",noOfRecordsNeed,"],named('", outX, "'));\n", sep = "")
	if(noOfRecordsNeed==0)
		out <- ''
	if(download) {
		eclQuery <<- sprintf("import STD;\n%s",eclQuery)
		out1 <- paste("OUTPUT(", out.dataframe,",,'~rhpcc::",outX, "',CSV(HEADING(SINGLE)));\n", sep = "")
		despray <- paste("Std.File.Despray('~rhpcc::",outX,"','",hpccHostName,"','/var/lib/HPCCSystems/mydropzone/",outX,".csv',,,,TRUE);\n",sep='')
		out <- paste(out1,despray,out,sep='')
		out <- paste(out,"STD.File.DeleteLogicalFile('~rhpcc::",outX,"');\n",sep='')
		hpccSessionVariables <<- rbind(hpccSessionVariables,c((length(hpccSessionVariables)/2)+1,outX))
	}
	hpcc.submit(out)
}


hpcc.submit <-
	function(code,submit=TRUE) {
		if(!submit)
			return(code)
		eclQuery <<- paste(eclQuery,code,sep='')
	}


hpcc.filter <- function(data,condition) {
	
	out.dataframe <- hpcc.get.name()
	data <- paste(out.dataframe,' := ',data,'(',condition,');\n ',sep="")
	hpcc.submit(data)
	return(out.dataframe)
}

hpcc.count <- function(dataset) {
	
	out.dataframe <- hpcc.get.name()
	code <- paste(out.dataframe,' := COUNT(',in.data,');\n');
	hpcc.submit(code)
	return(out.dataframe)
}


hpcc.sort <-
	function (dataframe, fields,joined = NULL, skew = NULL, 
			  threshold = NULL, few = NULL, joinedset = NULL, limit = NULL, 
			  target = NULL, size = NULL, local = NULL, stable = NULL, 
			  unstable = NULL, algorithm = NULL) 
	{
		out.dataframe <- hpcc.get.name()
		strim <- function(x) {
			gsub("^\\s+|\\s+$", "", x)
			gsub("^,+|,+$", "", x)
		}
		is.not.null <- function(x) !is.null(x)
		if (missing(dataframe)) {
			stop("no dataframe.")
		}
		else {
			if (is.not.null(joined)) {
				joinstr <- strim(sprintf("%s(%s)",joined,joinedset))
			}
			else {
				joinstr <- strim(joined)
			}
			if (is.not.null(skew)) {
				limt <- strim(sprintf("%s,%s",limit, target))
				skewstr <- strim(sprintf("%s(%s)",skew,limt))
			}
			else {
				skewstr <- strim(skew)
			}
			if (is.not.null(threshold)) {
				threstr <- strim(sprintf("%s(%s)",threshold,size))
			}
			else {
				threstr <- strim(threshold)
			}
			if (is.not.null(stable)) {
				stabstr <- strim(sprintf("%s(%s)",stable,algorithm))
			}
			else {
				stabstr <- strim(stable)
			}
			if (is.not.null(unstable)) {
				unstabstr <- strim(pastesprintf("%s(%s)",unstable,algorithm))
				
			}
			else {
				unstabstr <- strim(unstable)
			}
			str1 <- strim(sprintf("%s,%s,%s",dataframe, fields, joinstr))
			str2 <- strim(sprintf("%s,%s",str1, skewstr))
			str3 <- strim(sprintf("%s,%s",str2, threstr))
			str4 <- strim(sprintf("%s,%s",str3, stabstr))
			str5 <- strim(sprintf("%s,%s",str4, unstabstr))
			str6 <- strim(sprintf("%s,%s",str5, local))
			str7 <- strim(sprintf("%s,%s",str6, few))
			xyz <- strim(sprintf("%s := SORT(%s);", out.dataframe, str7))
			
			xyz <- sprintf("%s := SORT(%s,%s);",out.dataframe,dataframe,fields)
			hpcc.submit(xyz)
			return(out.dataframe)
		}
	}



hpcc.min <-
	function(dataframe,fields) {
		
		strim<-function (dataframe)
		{
			gsub("^\\s+|\\s+$", "", dataframe)
		}
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			
			charh<-sprintf("'%s'",h[[1]][1])
			str1<-strim(sprintf("%s,%s",str1,charh))
			hh<-strim(sprintf("LEFT.%s",h[[1]][1]))
			str2<-strim(sprintf("%s,%s",str2,hh))		
		}
		recmin <- hpcc.get.name()
		xyz <- recmin
		xyz<-sprintf("%s :=RECORD\n",xyz)
		xyz<-sprintf("%sINTEGER3 id;\n",xyz)
		xyz<-sprintf("%s %s ;\nEND;\n",xyz,dataframe)
		mintrans <- hpcc.get.name()
		xyz<-sprintf("%s%s %s (%s L, INTEGER C) := TRANSFORM\n",xyz,recmin,mintrans,dataframe)
		xyz<-sprintf("%sSELF.id :=C;\n",xyz)
		xyz<-sprintf("%sSELF :=L;\nEND;\n",xyz)
		DSRMIN <- hpcc.get.name()
		xyz<-sprintf("%s%s:=PROJECT(%s,%s(LEFT,COUNTER));\n",xyz,DSRMIN,dataframe,mintrans)
		NumField <-  hpcc.get.name()
		xyz<-sprintf("%s%s:=RECORD\n",xyz,NumField)
		xyz<-sprintf("%sUNSIGNED id;\n",xyz)
		xyz<-sprintf("%sSTRING Field;\nREAL8 value;\nEND;\n",xyz)
		OutDsMin <- hpcc.get.name()
		xyz<-sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM(%s,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
					 (COUNTER%s);SELF.value:=CHOOSE(COUNTER%s)));\n",
					 xyz,OutDsMin,DSRMIN,length(varlst[[1]]),NumField,str1,str2)
		
		SingleField <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,SingleField)
		xyz<-sprintf("%s%s.Field;\n",xyz,OutDsMin)
		xyz<-sprintf("%sMinval := MIN(GROUP,%s.value);\nEND;\n",xyz,OutDsMin)
		xyz<-sprintf("%s%s:= TABLE(%s,%s,Field);\n",xyz,out.dataframe,OutDsMin,SingleField)
		hpcc.submit(xyz)
		return(out.dataframe)
	}


hpcc.max <-
	function(dataframe,fields){
		
		strim<-function (dataframe)
		{
			gsub("^\\s+|\\s+$", "", dataframe)
		}
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			charh<-paste("'",h[[1]][1],"'",sep="")
			str1<-strim(paste(str1,charh,sep=","))
			hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
			str2<-strim(paste(str2,hh,sep=","))
			
		}
		recmax <- hpcc.get.name()
		code <- recmax
		code<-sprintf("%s :=RECORD\n",recmax)
		code<-sprintf("%sINTEGER3 id;\n",code)
		code<-sprintf("%s%s;\n",code,dataframe)
		code<-sprintf("%sEND;\n",code)
		maxtrans <- hpcc.get.name()
		code<-sprintf("%s%s %s (%s L, INTEGER C) := TRANSFORM\n",code,recmax,maxtrans,dataframe)
		code<-sprintf("%sSELF.id := C;\n",code)
		code<-sprintf("%sSELF :=L;\n",code)
		code<-sprintf("%sEND;\n",code)
		DSRMAX <- hpcc.get.name()
		code<-sprintf("%s%s:=PROJECT(%s,%s(LEFT,COUNTER));\n",code,DSRMAX,dataframe,maxtrans)
		MaxField <-  hpcc.get.name()
		code<-sprintf("%s%s:=RECORD\n",code,MaxField)
		code<-sprintf("%sUNSIGNED id;\n",code)
		code<-sprintf("%sSTRING Field;\n",code)
		code<-sprintf("%sREAL8 value;\nEND;\n",code)
		OutDsMax <- hpcc.get.name()

		code<-sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM(%s,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
					  (COUNTER%s);SELF.value:=CHOOSE(COUNTER%s)));\n",
					  code,OutDsMax,DSRMAX,length(varlst[[1]]),MaxField,str1,str2)
		SinglemaxField <- hpcc.get.name()
		code<-sprintf("%s%s := RECORD\n",code,SinglemaxField)
		code<-sprintf("%s%s.Field;\n",code,OutDsMax)
		code<-sprintf("%sMaxval := MAX(GROUP,%s.value);\nEND;\n",code,OutDsMax)
		code<-sprintf("%s%s:= TABLE(%s,%s,Field);\n",code,out.dataframe,OutDsMax,SinglemaxField)
		hpcc.submit(code)
		return(out.dataframe)
	}

hpcc.mode <-
	function(dataframe,fields){
		
		strim<-function (dataframe)
		{
			gsub("^\\s+|\\s+$", "", dataframe)
		}
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			charh<-paste("'",h[[1]][1],"'",sep="")
			str1<-strim(paste(str1,charh,sep=","))
			hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
			str2<-strim(paste(str2,hh,sep=","))
			
		}
		recmax <- hpcc.get.name()
		xyz<-sprintf("%s :=RECORD\n",recmax)
		xyz<-sprintf("%sINTEGER3 id;\n",xyz)
		xyz<-sprintf("%s%s;\nEND;\n",xyz,dataframe)
		maxtrans <- hpcc.get.name()
		xyz<-sprintf("%s%s %s (%s L, INTEGER C) := TRANSFORM\n",xyz,recmax,maxtrans,dataframe)
		xyz<-sprintf("%sSELF.id :=C;\n",xyz)
		xyz<-sprintf("%sSELF :=L;\nEND;\n",xyz)
		DSRMAX <- hpcc.get.name()
		xyz<-sprintf("%s%s:=PROJECT(%s,%s(LEFT,COUNTER));\n",xyz,DSRMAX,dataframe,maxtrans)
		MaxField <- hpcc.get.name()
		xyz<-sprintf("%s%s:=RECORD\n",xyz,MaxField)
		xyz<-sprintf("%sUNSIGNED id;\n",xyz)
		xyz<-sprintf("%sSTRING Field;\n",xyz)
		xyz<-sprintf("%sUNSIGNED4 number;\n",xyz)
		xyz<-sprintf("%sREAL8 value;\nEND;\n",xyz)
		OutDsMode <- hpcc.get.name()
		xyz<-sprintf("%s%s:=NORMALIZE(%s,%s,
					 TRANSFORM(%s,SELF.id:=LEFT.id,SELF.number:=COUNTER;
					 SELF.Field:=CHOOSE(COUNTER%s);
					 SELF.value:=CHOOSE(COUNTER%s)));\n",xyz,
					 OutDsMode,DSRMAX,length(varlst[[1]]),MaxField,str1,str2)
		
		
		
		RankableField <- hpcc.get.name()
		xyz <- sprintf("%s%s := RECORD\n",xyz,RankableField)
		xyz<-sprintf("%s%s;\n",xyz,OutDsMode)
		xyz<-sprintf("%sUNSIGNED Pos := 0;\nEND;\n",xyz)
		Ta <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(SORT(%s,Number,field,Value),%s);\n",xyz,Ta,OutDsMode,RankableField)
		add_rank <- hpcc.get.name()
		xyz<-sprintf("%sTYPEOF(%s) %s(%s le,UNSIGNED c) := TRANSFORM\n",xyz,Ta,add_rank,Ta)
		xyz<-sprintf("%sSELF.Pos := c;\n",xyz)
		xyz<-sprintf("%sSELF := le;\nEND;\n",xyz)
		P <- hpcc.get.name()
		xyz<-sprintf("%s %s:= PROJECT(%s,%s(LEFT,COUNTER));\n",xyz,P,Ta,add_rank) 
		RS <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,RS)
		xyz<-sprintf("%sSeq := MIN(GROUP,%s.pos);\n",xyz,P)
		xyz<-sprintf("%s%s.number;\n",xyz,P)
		xyz<-sprintf("%s%s.field;\nEND;\n",xyz,P)
		Splits <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,FEW);\n",xyz,Splits,P,RS)
		xyz<-sprintf("%sTYPEOF(%s) to(%s le,%s ri) := TRANSFORM\n",xyz,Ta,P,Splits)
		xyz<-sprintf("%sSELF.pos := 1+le.pos - ri.Seq;\n",xyz)
		xyz<-sprintf("%sSELF := le;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		outfile <- hpcc.get.name()
		xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.number=RIGHT.number,to(LEFT,RIGHT),LOOKUP);\n",xyz,outfile,P,Splits)
		xyz<-sprintf("%sn := COUNT(%s);\n",xyz,OutDsMode)
		ModeRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,ModeRec)
		xyz<-sprintf("%s%s.number;\n",xyz,outfile)
		xyz<-sprintf("%s%s.value;\n",xyz,outfile)
		xyz<-sprintf("%s%s.field;\n",xyz,outfile)
		xyz<-sprintf("%s%s.pos;\n",xyz,outfile)
		xyz<-sprintf("%svals := COUNT(GROUP);\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		MTable <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,value);\n",xyz,MTable,outfile,ModeRec)
		newRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,newRec)
		xyz<-sprintf("%s%s.number;\n",xyz,MTable)
		xyz<-sprintf("%s%s.value;\n",xyz,MTable)
		xyz<-sprintf("%s%s.field;\n",xyz,MTable)
		xyz<-sprintf("%spo := (%s.pos*%s.vals + ((%s.vals-1)*%s.vals/2))/%s.vals;\n",
					 xyz,MTable,MTable,MTable,MTable,MTable)
		xyz<-sprintf("%sEND;\n",xyz)
		
		newTable <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s);\n",xyz,newTable,MTable,newRec)
		modT <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,{number,cnt:=MAX(GROUP,vals)},number);\n",xyz,modT,MTable)
		Modes <- hpcc.get.name()
		xyz<-sprintf("%s%s:=JOIN(%s,%s,LEFT.number=RIGHT.number AND LEFT.vals=RIGHT.cnt);\n",
					 xyz,Modes,MTable,modT)
		ModesRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,ModesRec)
		xyz<-sprintf("%sfield := %s.field;\n",xyz,Modes)
		xyz<-sprintf("%smode := %s.value;\n",xyz,Modes)
		xyz<-sprintf("%s%s.cnt;\n",xyz,Modes)
		xyz<-sprintf("%sEND;\n",xyz)
		
		xyz<-sprintf("%s%s:= TABLE(%s,%s);\n",xyz,out.dataframe,Modes,ModesRec)
		hpcc.submit(xyz)
		return(out.dataframe)
	}


hpcc.median <-
	function(dataframe,fields){
		
		strim<-function (dataframe)
		{
			gsub("^\\s+|\\s+$", "", dataframe)
		}
		
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			
			charh<-paste("'",h[[1]][1],"'",sep="")
			str1<-strim(paste(str1,charh,sep=","))
			hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
			str2<-strim(paste(str2,hh,sep=","))
		}
		
		recmax <- hpcc.get.name()
		xyz<-sprintf("%s :=RECORD\n",recmax)
		xyz<-sprintf("%sINTEGER3 id;\n",xyz)
		xyz<-sprintf("%s%s;\nEND;\n",xyz,dataframe)
		maxtrans <- hpcc.get.name()
		xyz<-sprintf("%s%s %s (%s L, INTEGER C) := TRANSFORM\n",xyz,recmax,maxtrans,dataframe)
		xyz<-sprintf("%sSELF.id :=C;\n",xyz)
		xyz<-sprintf("%sSELF :=L;\nEND;\n",xyz)
		DSRMAX <- hpcc.get.name()
		xyz<-sprintf("%s%s:=PROJECT(%s,%s(LEFT,COUNTER));\n",xyz,DSRMAX,dataframe,maxtrans)
		MaxField <- hpcc.get.name()
		xyz<-sprintf("%s%s:=RECORD\n",xyz,MaxField)
		xyz<-sprintf("%sUNSIGNED id;\n",xyz)
		xyz<-sprintf("%sUNSIGNED4 number;\n",xyz)
		xyz<-sprintf("%sSTRING Field;\n",xyz)
		xyz<-sprintf("%sREAL8 value;\nEND;\n",xyz)
		
		OutDsMed <- hpcc.get.name()
		xyz<-sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM(%s,SELF.id:=LEFT.id,SELF.number:=COUNTER;
					 SELF.Field:=CHOOSE(COUNTER%s);SELF.value:=CHOOSE(COUNTER%s)));\n",
					 xyz,OutDsMed,DSRMAX,length(varlst[[1]]),MaxField,str1,str2)
		
		
		RankableField <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,RankableField)
		xyz<-sprintf("%s%s;\n",xyz,OutDsMed)
		xyz<-sprintf("%sUNSIGNED Pos := 0;\nEND;\n",xyz)
		
		Ta <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(SORT(%s,Number,field,Value),%s);\n",xyz,Ta,OutDsMed,RankableField)
		
		xyz<-sprintf("%sTYPEOF(%s) add_rank(%s le,UNSIGNED c) := TRANSFORM\n",xyz,Ta,Ta)
		xyz<-sprintf("%sSELF.Pos := c;\n",xyz)
		xyz<-sprintf("%sSELF := le;\nEND;\n",xyz)
		
		P <- hpcc.get.name()
		xyz<-sprintf("%s%s := PROJECT(%s,add_rank(LEFT,COUNTER));\n",xyz,P,Ta)  
		RS <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,RS)
		xyz<-sprintf("%sSeq := MIN(GROUP,%s.pos);\n",xyz,P)
		xyz<-sprintf("%s%s.number;\n",xyz,P)
		xyz<-sprintf("%s%s.field;\n",xyz,P)
		xyz<-sprintf("%sEND;\n",xyz)
		Splits <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,FEW);\n",xyz,Splits,P,RS)
		xyz<-sprintf("%sTYPEOF(%s) to(%s le,%s ri) := TRANSFORM\n",xyz,Ta,P,Splits)
		xyz<-sprintf("%sSELF.pos := 1+le.pos - ri.Seq;\n",xyz)
		xyz<-sprintf("%sSELF := le;\nEND;\n",xyz)
		outfile <- hpcc.get.name()
		xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.number=RIGHT.number,to(LEFT,RIGHT),LOOKUP);\n",xyz,outfile,P,Splits)
		n <- hpcc.get.name()
		xyz<-sprintf("%s%s := COUNT(%s);\n",xyz,n,DSRMAX)
		MedRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,MedRec)
		xyz<-sprintf("%s%s.number;\n",xyz,outfile)
		xyz<-sprintf("%sSET OF UNSIGNED poso := IF(%s%s2=0,[%s/2,%s/2 + 1],[(%s+1)/2]);\nEND;\n",xyz,n,'%',n,n,n)
		MyT <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,field,number);\n",xyz,MyT,outfile,MedRec)
		MedianValues <- hpcc.get.name()
		xyz<-sprintf("%s%s:=JOIN(%s,%s,LEFT.number=RIGHT.number AND LEFT.pos IN RIGHT.poso);\n",
					 xyz,MedianValues,outfile,MyT)
		medianRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,medianRec)
		xyz<-sprintf("%s%s.field;\n",xyz,MedianValues)
		xyz<-sprintf("%sMedian := AVE(GROUP, %s.value);\n",xyz,MedianValues)
		xyz<-sprintf("%sEND;\n",xyz)
		
		xyz<-sprintf("%s%s:= TABLE(%s,%s,field);\n",xyz,out.dataframe,MedianValues,medianRec)
		hpcc.submit(xyz)
		return(out.dataframe)
	}

hpcc.mean <-
	function(dataframe,fields){
		
		strim<-function (dataframe)
		{
			gsub("^\\s+|\\s+$", "", dataframe)
		}
		
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			
			charh<-paste("'",h[[1]][1],"'",sep="")
			str1<-strim(paste(str1,charh,sep=","))
			hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
			str2<-strim(paste(str2,hh,sep=","))
		}
		recavg <- hpcc.get.name()
		code<-sprintf("%s :=RECORD\n",recavg)
		code<-sprintf("%sINTEGER3 id;\n",code)
		code<-sprintf("%s%s;\nEND;\n",code,dataframe)
		avgtrans <- hpcc.get.name()
		code<-sprintf("%s%s %s (%s L, INTEGER C) := TRANSFORM\n",code,recavg,avgtrans,dataframe)
		code<-sprintf("%sSELF.id :=C;\n",code)
		code<-sprintf("%sSELF :=L;\nEND;\n",code)
		DSRAVG <- hpcc.get.name()
		code<-sprintf("%s%s:=PROJECT(%s,%s(LEFT,COUNTER));\n",code,DSRAVG,dataframe,avgtrans)
		NumAvgField <- hpcc.get.name()
		code<-sprintf("%s%s:=RECORD\n",code,NumAvgField)
		code<-sprintf("%sUNSIGNED id;\n",code)
		code<-sprintf("%sSTRING field;\n",code)
		code<-sprintf("%sREAL8 value;\nEND;\n",code)
		OutDsavg <- hpcc.get.name()
		code<-sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM
							  (%s,SELF.id:=LEFT.id,SELF.field:=CHOOSE
							  (COUNTER%s);SELF.value:=CHOOSE(COUNTER%s)));\n",
					  code,OutDsavg,DSRAVG,length(varlst[[1]]),NumAvgField,str1,str2)
		
		SingleavgField <- hpcc.get.name()
		code<-sprintf("%s%s := RECORD\n",code,SingleavgField)
		code<-sprintf("%s%s.field;\n",code,OutDsavg)
		code<-sprintf("%sMean := AVE(GROUP,%s.value);\nEND;\n",code,OutDsavg)
		code<-sprintf("%s%s:= TABLE(%s,%s,field);\n",code,out.dataframe,OutDsavg,SingleavgField)
		hpcc.submit(code)
		return(out.dataframe)
	}

hpcc.percentile <- function(dataset,...) {
	parameters <- list(...)
	if(length(parameters)%%2!=0)
		stop('Parameters are wrong')
	out.dataframe <- hpcc.get.name()
	fieldsRaw <- parameters[seq.int(1,length(parameters),2)]
	percentilesRaw <- parameters[seq.int(2,length(parameters),2)]
	value <- ''
	field <- ''
	percents <- ''
	normalize <- ''
	high <- 0
	for(i in 1:length(fieldsRaw)) {
		if(length(percentilesRaw[[i]])>high) 
			high <- length(percentilesRaw[[i]])
		if(i == length(fieldsRaw)){
			value <-  paste(value,"LEFT.",fieldsRaw[[i]],sep='')
			field <- paste(field,"'",fieldsRaw[[i]],"'",sep='')   			
			normalize <- paste(normalize,fieldsRaw[[i]],"P[COUNTER]",sep='')
		}
		else {
			value <- paste(value,'LEFT.',fieldsRaw[[i]],',',sep='',collapse=NULL)
			field <- paste(field,"'",fieldsRaw[[i]],"',",sep='')
			normalize <- paste(normalize,"IF(SELF.field='",fieldsRaw[[i]],"',",fieldsRaw[[i]],'P[COUNTER],',sep='')
		}
		percents <- paste(percents,"SET OF INTEGER ",fieldsRaw[[i]],"P := [0,1,5,10,25,50,75,90,95,99,100",sep='')
		dfg <- paste('',percentilesRaw[[i]],sep='',collapse=',')
		percents <- paste(percents,",",dfg,"];\n",sep='',collapse=NULL)			
	}
	
	for(i in 1:length(fieldsRaw)) {
		normalize <- paste(normalize,")",sep='')
	}
	
	NormRec <- hpcc.get.name()
	percentile <- sprintf("%s:=RECORD\nINTEGER4 number;\nSTRING field;\nREAL value;\nEND;\n",NormRec)
	
	OutDS <- hpcc.get.name()
	percentile <- sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM(%s,SELF.number:=COUNTER,
						  SELF.field:=CHOOSE(COUNTER,%s),
						  SELF.value:=CHOOSE(COUNTER,%s)));\n",
						  percentile,OutDS,dataset,length(fieldsRaw),NormRec,field,value)
	RankableField <- hpcc.get.name()
	percentile <- sprintf("%s%s := RECORD\n%s;\nUNSIGNED pos:=0;\nEND;\n",percentile,RankableField,OutDS)
	Ta <- hpcc.get.name()
	percentile <- sprintf("%s%s:=TABLE(SORT(%s,field,Value),%s);\n",percentile,Ta,OutDS,RankableField)
	percentile <- sprintf("%sTYPEOF(%s) add_rank(%s le, UNSIGNED c):=TRANSFORM\nSELF.pos:=c;\nSELF:=le;\nEND;\n",
						  percentile,Ta,Ta)
	P <- hpcc.get.name()
	percentile <- sprintf("%s%s:=PROJECT(%s,add_rank(LEFT,COUNTER));\n",percentile,P,Ta)
	RS <- hpcc.get.name()
	percentile <- sprintf("%s%s:=RECORD\nSeq:=MIN(GROUP,%s.pos);\n%s.field;\nEND;\n",
						  percentile,RS,P,P)
	Splits <- hpcc.get.name()
	percentile <- sprintf("%s%s := TABLE(%s,%s,field,FEW);\n",percentile,Splits,P,RS)
	to <- hpcc.get.name()
	percentile <- sprintf("%sTYPEOF(%s) %s(%s le, %s ri):=TRANSFORM\nSELF.pos:=1+le.pos-ri.Seq;\nSELF:=le;\nEND;\n"
						  ,percentile,Ta,to,P,Splits)
	outfile <- hpcc.get.name()
	percentile <- sprintf("%s%s := JOIN(%s,%s,LEFT.field=RIGHT.field, %s(LEFT,RIGHT),LOOKUP);\n"
						  ,percentile,outfile,P,Splits,to)
	
	N <- hpcc.get.name()
	percentile <- sprintf("%s%s:=COUNT(%s);\n",percentile,N,dataset)
	percentile <- paste(percentile, percents,sep='')
	Rec1 <- hpcc.get.name()
	percentile <- sprintf("%s%s:=RECORD\nSTRING field;\nINTEGER4 percentiles;\nEND;\n",
						  percentile,Rec1)
	
	MyTab <- hpcc.get.name()
	percentile <- paste(percentile,MyTab,":=NORMALIZE(",Splits,",",(11+high),",TRANSFORM(",Rec1,",SELF.field:=LEFT.field,
						SELF.percentiles:=",normalize,");\n",sep='')
	
	PerRec <- hpcc.get.name()
	percentile <- sprintf("%s%s:=RECORD\n%s;\nREAL rank:=IF(%s.percentiles = -1,0,
						  IF(%s.percentiles = 0,1,
						  IF(ROUND(%s.percentiles*(%s+1)/100)>=%s,%s,
						  %s.percentiles*(%s+1)/100)));\nEND;\n",
						  percentile,PerRec,MyTab,MyTab,MyTab,MyTab,N,N,N,MyTab,N)
	valuestab <- hpcc.get.name()
	percentile <- sprintf("%s%s := TABLE(%s,%s);\n",percentile,valuestab,MyTab,PerRec)
	rankRec <- hpcc.get.name()
	percentile <- sprintf("%s%s := RECORD\nSTRING field := %s.field;\n
						  REAL rank := %s.rank;\nINTEGER4 intranks;\nREAL decranks;\n
						  INTEGER4 plusOneranks;\n
						  %s.percentiles;\nEND;\n",
						  percentile,rankRec,valuestab,valuestab,valuestab)
	tr <- hpcc.get.name()
	percentile <- sprintf("%s%s %s(%s L, INTEGER C) := TRANSFORM\n
						  SELF.decranks := IF(L.rank - (ROUNDUP(L.rank) - 1) = 
						  1,0,L.rank - (ROUNDUP(L.rank) - 1));\n						  
						  SELF.intranks := IF(ROUNDUP(L.rank) = L.rank,L.rank,(ROUNDUP(L.rank) - 1));\n
						  SELF.plusOneranks := SELF.intranks + 1;\n
						  SELF := L;\n
						  END;\n",percentile,rankRec,tr,valuestab)
	ranksTab <- hpcc.get.name()
	percentile <- sprintf("%s%s := PROJECT(%s,%s(LEFT,COUNTER));\n",percentile,ranksTab,valuestab,tr)
	ranksRec <- hpcc.get.name()
	percentile <- sprintf("%s%s := RECORD\nSTRING field;\n%s.decranks;\n%s.percentiles;\n
						  INTEGER4 ranks;\nEND;\n"
						  ,percentile,ranksRec,ranksTab,ranksTab)
	rankTab <- hpcc.get.name()
	percentile <- sprintf("%s%s := NORMALIZE(%s,2,TRANSFORM(%s,SELF.field := LEFT.field; 
						  SELF.ranks := CHOOSE(COUNTER,LEFT.intranks,LEFT.plusOneranks),SELF := LEFT));\n",
						  percentile,rankTab,ranksTab,ranksRec)
	MTable <-hpcc.get.name()
	percentile <- sprintf("%s%s:=SORT(JOIN(%s, %s, LEFT.field = RIGHT.field AND 
						  LEFT.ranks = RIGHT.pos),field,percentiles,ranks);\n",
						  percentile,MTable,rankTab,outfile)
	MyTable <- hpcc.get.name()
	percentile <- sprintf("%s%s := DEDUP(%s, LEFT.percentiles = RIGHT.percentiles AND 
						  LEFT.ranks = RIGHT.ranks AND LEFT.field = RIGHT.field);\n"
						  ,percentile,MyTable,MTable)
	RollThem <- hpcc.get.name()
	percentile <- sprintf("%s%s %s(%s L, %s R) := TRANSFORM\nSELF.value := L.value + L.decranks*(R.value - L.value);\nSELF := L;\nEND;\n"
						  ,percentile,MyTable,RollThem,MyTable,MyTable)
	beforeOut <- hpcc.get.name()
	percentile <- paste(percentile,beforeOut, ":= ROLLUP(",MyTable,", LEFT.percentiles = RIGHT.percentiles 
						AND LEFT.field=RIGHT.field, ",RollThem,"(LEFT,RIGHT));\n",sep='')
	percentile <- sprintf("%s%s := TABLE(%s,{field,percentiles,value});\n",percentile,out.dataframe,beforeOut)
	hpcc.submit(percentile)
	return(out.dataframe)
}

hpcc.corr <-
	function(dataframe,fields,method) {
		
		strim<-function (x)
		{
			gsub("^\\s+|\\s+$", "", x)
			gsub("^,+|,+$", "", x)
		}
		out.dataframe <- hpcc.get.name()
		varlst<-strsplit(fields, ",")
		str1<-''
		str2<-''
		for (i in 1:length(varlst[[1]]))
		{
			k<-strim(varlst[[1]][i])
			h<-strsplit(k," ")
			charh<-paste("'",h[[1]][1],"'",sep="")
			str1<-strim(paste(str1,charh,sep=","))
			hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
			str2<-strim(paste(str2,hh,sep=","))
			
		}
		recmax <- hpcc.get.name()
		xyz<-sprintf("%s :=RECORD\n",recmax)
		xyz<-sprintf("%sINTEGER3 id; \n",xyz)
		xyz<-paste(xyz,paste(dataframe,";"),"\n")
		xyz<-sprintf("%sEND;\n",xyz)
		maxtrans <- hpcc.get.name()
		xyz<-sprintf("%s%s %s (%s  L, INTEGER C) := TRANSFORM\n",xyz,recmax,maxtrans,dataframe)
		xyz<-sprintf("%sSELF.id :=C;\n",xyz)
		xyz<-sprintf("%sSELF :=L;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		DSRMAX <- hpcc.get.name()
		xyz<-sprintf("%s%s:=PROJECT(%s ,%s(LEFT,COUNTER));\n",xyz,DSRMAX,dataframe,maxtrans)
		
		NumericField <- hpcc.get.name()
		xyz<-sprintf("%s%s :=RECORD\n",xyz,NumericField)
		xyz<-sprintf("%sUNSIGNED id;\n",xyz)
		xyz<-sprintf("%sUNSIGNED4 number;\n",xyz)
		xyz<-sprintf("%sREAL8 value;\n",xyz)
		xyz<-sprintf("%sSTRING field;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		
		OutDs <- hpcc.get.name()
		xyz<-sprintf("%s%s:=NORMALIZE(%s,%s,TRANSFORM(%s,SELF.id:=LEFT.id,
					 SELF.number:=COUNTER;
					 SELF.field:=CHOOSE(COUNTER,%s);
					 SELF.value:=CHOOSE(COUNTER,%s)));\n"
					 ,xyz,OutDs,DSRMAX,length(varlst[[1]]),NumericField,str1,str2)
		
		RankableField <- hpcc.get.name()
		xyz<-sprintf("%s%s :=RECORD\n",xyz,RankableField)
		xyz<-sprintf("%s%s;\n",xyz,OutDs)
		xyz<-sprintf("%sUNSIGNED Pos := 0;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		Ta <- hpcc.get.name()
		xyz<-sprintf("%s%s :=TABLE(SORT(%s,Number,field,Value),%s);\n"
					 ,xyz,Ta,OutDs,RankableField)
		
		add_rank <- hpcc.get.name()
		xyz<-sprintf("%sTYPEOF(%s) %s(%s le,UNSIGNED c) := TRANSFORM\n",xyz,Ta,add_rank,Ta)
		xyz<-sprintf("%sSELF.Pos := c;\n",xyz)
		xyz<-sprintf("%sSELF := le;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		P <- hpcc.get.name()
		xyz<-sprintf("%s%s := PROJECT(%s,%s(LEFT,COUNTER));\n",xyz,P,Ta,add_rank)
		RS <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,RS)
		xyz<-sprintf("%sSeq := MIN(GROUP,%s.pos);\n",xyz,P)
		xyz<-sprintf("%s%s.number;\n",xyz,P)
		xyz<-sprintf("%sEND;\n",xyz)
		Splits <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,number,FEW);\n",xyz,Splits,P,RS)
		
		to <- hpcc.get.name()
		xyz<-sprintf("%sTYPEOF(%s) %s(%s le,%s ri) := TRANSFORM\n",xyz,Ta,to,P,Splits)
		xyz<-sprintf("%sSELF.pos := 1+le.pos - ri.Seq;\n",xyz)
		xyz<-sprintf("%sSELF := le;\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		outfile <- hpcc.get.name()
		xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.number=RIGHT.number,%s(LEFT,RIGHT),LOOKUP);\n"
					 ,xyz,outfile,P,Splits,to)
		
		modeRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,modeRec)
		xyz<-sprintf("%s%s.number;\n",xyz,outfile)
		xyz<-sprintf("%s%s.value;\n",xyz,outfile)
		xyz<-sprintf("%s%s.pos;\n",xyz,outfile)
		xyz<-sprintf("%s%s.field;\n",xyz,outfile)
		xyz<-sprintf("%svals := COUNT(GROUP);\n",xyz)
		xyz<-sprintf("%sEND;\n",xyz)
		MTable <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,value);\n",xyz,MTable,outfile,modeRec)
		#xyz<-sprintf("%sMTable;\n",xyz)
		
		newRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,newRec)
		xyz<-sprintf("%s%s.number;\n",xyz,MTable)
		xyz<-sprintf("%s%s.value;\n",xyz,MTable)
		xyz<-sprintf("%s%s.field;\n",xyz,MTable)
		xyz<-sprintf("%spo := (%s.pos*%s.vals + ((%s.vals-1)*%s.vals/2))/%s.vals;\n",
					 xyz,MTable,MTable,MTable,MTable,MTable)
		xyz<-sprintf("%sEND;\n",xyz)
		
		newTable <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s);\n",xyz,newTable,MTable,newRec)
		#xyz<-sprintf("%sOUTPUT(newTable,NAMED('TEST'));\n",xyz)
		TestTab <- hpcc.get.name()
		xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.number = RIGHT.number AND LEFT.value = RIGHT.value);\n",
					 xyz,TestTab,outfile,newTable)
		#xyz<-sprintf("%sTestTab;\n",xyz)
		
		MyRec <- hpcc.get.name()
		xyz<-sprintf("%s%s := RECORD\n",xyz,MyRec)
		xyz<-sprintf("%s%s;\n",xyz,TestTab)
		xyz<-sprintf("%sEND;\n",xyz)
		T1 <- hpcc.get.name()
		xyz<-sprintf("%s%s := TABLE(%s,%s,id,number,field);\n",xyz,T1,TestTab,MyRec)
		
		SingleForm <- hpcc.get.name()
		single <- hpcc.get.name()
		PairRec <- hpcc.get.name()
		note_prod <- hpcc.get.name()
		pairs <- hpcc.get.name()
		PairAccum <- hpcc.get.name()
		exys <- hpcc.get.name()
		with_x <- hpcc.get.name()
		Rec <- hpcc.get.name()
		n <- hpcc.get.name()
		Trans <- hpcc.get.name()
		intjoin <- hpcc.get.name()
		
		if (method=='S')
		{
			xyz<-sprintf("%s%s := Record\n",xyz,SingleForm)
			xyz<-sprintf("%s%s.number;\n",xyz,T1)
			xyz<-sprintf("%s%s.field;\n",xyz,T1)
			xyz<-sprintf("%sREAL8 meanS := AVE(GROUP,%s.po);\n",xyz,T1)
			xyz<-sprintf("%sREAL8 sdS := SQRT(VARIANCE(GROUP,%s.po));\n",xyz,T1)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,FEW);",xyz,single,T1,SingleForm)
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,PairRec)
			xyz<-sprintf("%sUNSIGNED4 left_number;\n",xyz)
			xyz<-sprintf("%sUNSIGNED4 right_number;\n",xyz)
			xyz<-sprintf("%sSTRING left_field;\n",xyz)
			xyz<-sprintf("%sSTRING right_field;\n",xyz)
			xyz<-sprintf("%sREAL8   xyS;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s %s(%s L, %s R) := TRANSFORM\n",xyz,PairRec,note_prod,T1,T1)
			xyz<-sprintf("%sSELF.left_number := L.number;\n",xyz)
			xyz<-sprintf("%sSELF.right_number := R.number;\n",xyz)
			xyz<-sprintf("%sSELF.left_field := L.field;\n",xyz)
			xyz<-sprintf("%sSELF.right_field := R.field;\n",xyz)
			xyz<-sprintf("%sSELF.xyS := L.po*R.po;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.id=RIGHT.id AND LEFT.number<RIGHT.number,
						 %s(LEFT,RIGHT));\n"
						 ,xyz,pairs,T1,T1,note_prod)
			
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,PairAccum)
			xyz<-sprintf("%s%s.left_number;\n",xyz,pairs)
			xyz<-sprintf("%s%s.right_number;\n",xyz,pairs)
			xyz<-sprintf("%s%s.left_field;\n",xyz,pairs)
			xyz<-sprintf("%s%s.right_field;\n",xyz,pairs)
			xyz<-sprintf("%se_xyS := SUM(GROUP,%s.xyS);\n",xyz,pairs)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := TABLE(%s,%s,left_number,right_number,left_field,right_field,FEW);\n"
						 ,xyz,exys,pairs,PairAccum)
			xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.left_number = RIGHT.number,LOOKUP);\n"
						 ,xyz,with_x,exys,single)
			
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,Rec)
			xyz<-sprintf("%sUNSIGNED left_number;\n",xyz)
			xyz<-sprintf("%sUNSIGNED right_number;\n",xyz)
			xyz<-sprintf("%sSTRING left_field;\n",xyz)
			xyz<-sprintf("%sSTRING right_field;\n",xyz)
			xyz<-sprintf("%sREAL8 Spearman;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := COUNT(%s);\n",xyz,n,dataframe)
			
			
			xyz<-sprintf("%s%s %s(%s L, %s R) := TRANSFORM\n"
						 ,xyz,Rec,Trans,with_x,single)
			xyz<-sprintf("%sSELF.Spearman := (L.e_xyS - %s*L.meanS*R.meanS)/(%s*L.sdS*R.sdS);\n",xyz,n,n)
			xyz<-sprintf("%sSELF := L;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			xyz<-sprintf("%s%s:= JOIN(%s,%s,LEFT.right_number=RIGHT.number,%s(LEFT,RIGHT),LOOKUP);\n"
						 ,xyz,intjoin,with_x,single,Trans)
			xyz<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(",intjoin,",{left_field,right_field,Spearman}),
								 left_field,right_field);\n"))
		}
		else if (method=='P')
		{
			xyz<-sprintf("%s%s := Record\n",xyz,SingleForm)
			xyz<-sprintf("%s%s.number;\n",xyz,T1)
			xyz<-sprintf("%s%s.field;\n",xyz,T1)
			xyz<-sprintf("%sREAL8 meanP := AVE(GROUP,%s.value);\n",xyz,T1)
			xyz<-sprintf("%sREAL8 sdP := SQRT(VARIANCE(GROUP,%s.value));\n",xyz,T1)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := TABLE(%s,%s,number,field,FEW);",xyz,single,T1,SingleForm)
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,PairRec)
			xyz<-sprintf("%sUNSIGNED4 left_number;\n",xyz)
			xyz<-sprintf("%sUNSIGNED4 right_number;\n",xyz)
			xyz<-sprintf("%sSTRING left_field;\n",xyz)
			xyz<-sprintf("%sSTRING right_field;\n",xyz)
			xyz<-sprintf("%sREAL8   xyP;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s %s(%s L, %s R) := TRANSFORM\n",xyz,PairRec,note_prod,T1,T1)
			xyz<-sprintf("%sSELF.left_number := L.number;\n",xyz)
			xyz<-sprintf("%sSELF.right_number := R.number;\n",xyz)
			xyz<-sprintf("%sSELF.left_field := L.field;\n",xyz)
			xyz<-sprintf("%sSELF.right_field := R.field;\n",xyz)
			xyz<-sprintf("%sSELF.xyP := L.value*R.value;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.id=RIGHT.id AND LEFT.number<RIGHT.number,
						 %s(LEFT,RIGHT));\n"
						 ,xyz,pairs,T1,T1,note_prod)
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,PairAccum)
			xyz<-sprintf("%s%s.left_number;\n",xyz,pairs)
			xyz<-sprintf("%s%s.right_number;\n",xyz,pairs)
			xyz<-sprintf("%s%s.left_field;\n",xyz,pairs)
			xyz<-sprintf("%s%s.right_field;\n",xyz,pairs)
			xyz<-sprintf("%se_xyP := SUM(GROUP,%s.xyP);\n",xyz,pairs)
			xyz<-sprintf("%sEND;\n",xyz)
			
			xyz<-sprintf("%s%s := TABLE(%s,%s,left_number,right_number,left_field,right_field,FEW);\n"
						 ,xyz,exys,pairs,PairAccum)
			xyz<-sprintf("%s%s := JOIN(%s,%s,LEFT.left_number = RIGHT.number,LOOKUP);\n"
						 ,xyz,with_x,exys,single)
			
			xyz<-sprintf("%s%s := RECORD\n",xyz,Rec)
			xyz<-sprintf("%sUNSIGNED left_number;\n",xyz)
			xyz<-sprintf("%sUNSIGNED right_number;\n",xyz)
			xyz<-sprintf("%sSTRING left_field;\n",xyz)
			xyz<-sprintf("%sSTRING right_field;\n",xyz)
			xyz<-sprintf("%sREAL8 Pearson;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			xyz<-sprintf("%s%s := COUNT(%s);\n",xyz,n,dataframe)
			
			xyz<-sprintf("%s%s %s(%s L, %s R) := TRANSFORM\n"
						 ,xyz,Rec,Trans,with_x,single)
			xyz<-sprintf("%sSELF.Pearson := (L.e_xyP - %s*L.meanP*R.meanP)/(%s*L.sdP*R.sdP);\n",xyz,n,n)
			xyz<-sprintf("%sSELF := L;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			xyz<-paste(xyz,paste(intjoin,":= JOIN(",with_x,",",single,",LEFT.right_number=RIGHT.number,",Trans,"(LEFT,RIGHT),LOOKUP);"),"\n")
			xyz<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(",intjoin,",{left_field,right_field,Pearson}),
						 left_field,right_field);)\n"))
			
		}
		else
		{
			stop("no proper method")  
		}
		hpcc.submit(xyz)
		return(out.dataframe)
		}

hpcc.freq <-
	function(dataframe,fields,sortorder=NULL) {
		
		
		strim<-function (x)
		{
			gsub("^\\s+|\\s+$", "", x)
			gsub("^,+|,+$", "", x)
		}
		
		semitrim<-function(x)
		{
			gsub(";","",x)
		}
		
		out.dataframe <- hpcc.get.name()
		
		## split layout var types####
		## respective int and string combos## 
		semiperson<-'' #semitrim(personout)
		split_val<- strsplit(semiperson, "\n")
		int<-grep("integer",split_val[[1]])
		rl<-grep("real",split_val[[1]])
		una<-grep("unasign",split_val[[1]])
		dcml<-grep("decimal",split_val[[1]])
		dbl<-grep("double",split_val[[1]])
		real_int<-c(split_val[[1]][int],split_val[[1]][rl],split_val[[1]][una],split_val[[1]][dcml],split_val[[1]][dbl])
		str<-grep("string",split_val[[1]])
		uni<-grep("unicode",split_val[[1]])
		str_uni<-c(split_val[[1]][str],split_val[[1]][uni])
		
		num_new<-NA
		char_new<-NA
		
		##split the var string###  
		field_splt <- strsplit(fields, ",")
		for (i in 1:length(field_splt[[1]]))
		{
			j<-strim(field_splt[[1]][i])
			
			if (any(grepl(j,real_int)))
				num_new[i]<-j
			else
				char_new[i]<-j      
		}
		
		num_new<-na.omit(num_new)
		char_new<-na.omit(char_new)
		
		is.not.na <- function(x) !is.na(x) 
		is.not.null <- function(x) !is.null(x)
		
		if (is.not.na(char_new[1]))
		{
			varlst<-strsplit(char_new, ",")
			str1<-''
			str2<-''
			for (i in 1:length(char_new))
			{
				k<-strim(varlst[[i]][1])
				h<-strsplit(k," ")
				# 				if (i > 1)
				# 				{
				charh<-paste("'",h[[1]][1],"'",sep="")
				str1<-strim(paste(str1,charh,sep=","))
				hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
				str2<-strim(paste(str2,hh,sep=","))
				# 				}
				# 				else
				# 				{
				# 					charh<-paste("'",h[[1]][1],"'",sep="")
				# 					str1<-strim(paste(str1,charh))
				# 					hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
				# 					str2<-strim(paste(str2,hh))
				# 				}
			}
			NumericField <- hpcc.get.name()
			
			xyz<-sprintf("%s :=RECORD\n",NumericField)
			xyz<-sprintf("%sSTRING field;\n",xyz)
			xyz<-sprintf("%sSTRING value;\nEND;\n",xyz)
			OutDSStr <- hpcc.get.name()
			xyz<-paste(xyz,paste(OutDSStr," := NORMALIZE(",dataframe,",",length(varlst),",
								 TRANSFORM(",NumericField,",SELF.field:=CHOOSE(COUNTER,",str1,");
								 SELF.value:=CHOOSE(COUNTER,",str2,")));",sep=""),"\n")
			FreqRecStr <- hpcc.get.name()
			xyz<-sprintf("%s%s:=RECORD\n",xyz,FreqRecStr)
			xyz<-sprintf("%s%s.field;\n",xyz,OutDSStr)     
			xyz<-sprintf("%s%s.value;\n",xyz,OutDSStr)
			xyz<-sprintf("%sINTEGER frequency:=COUNT(GROUP);\n",xyz)
			xyz<-sprintf("%sREAL8 Percent:=(COUNT(GROUP)/COUNT(%s))*100;\nEND;\n",xyz,dataframe)
			Frequency1 <- hpcc.get.name()
			xyz<-paste(xyz,paste(Frequency1," := TABLE(",OutDSStr,",",FreqRecStr,",field,value,MERGE);"),"\n")
		} 
		
		
		if (is.not.na(num_new[1]))
		{
			
			varlst<-strsplit(num_new, ",")
			str1<-''
			str2<-''
			for (i in 1:length(num_new))
			{
				k<-strim(varlst[[i]][1])
				h<-strsplit(k," ")
				# 				if (i > 1)
				# 				{
				charh<-paste("'",h[[1]][1],"'",sep="")
				str1<-strim(paste(str1,charh,sep=","))
				hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
				str2<-strim(paste(str2,hh,sep=","))
				
			}
			NumField <- hpcc.get.name()
			xyz<-sprintf("%s%s:=RECORD\n",xyz,NumField)
			xyz<-sprintf("%sSTRING field;\n",xyz)
			xyz<-sprintf("%sREAL value;\n",xyz)
			xyz<-sprintf("%sEND;\n",xyz)
			OutDSNum <- hpcc.get.name()
			xyz<-paste(xyz,paste(OutDSNum," := NORMALIZE(",dataframe,",",length(varlst),",TRANSFORM(",NumField,",SELF.field:=CHOOSE(COUNTER,",str1,");
								 SELF.value:=CHOOSE(COUNTER,",str2,")));",sep=""),"\n")
			FreqRecNum <- hpcc.get.name()
			xyz<-sprintf("%s%s:=RECORD\n",xyz,FreqRecNum)
			xyz<-sprintf("%s%s.field;\n",xyz,OutDSNum)
			xyz<-sprintf("%s%s.value;\n",xyz,OutDSNum)
			xyz<-sprintf("%sINTEGER frequency:=COUNT(GROUP);\n",xyz)
			xyz<-sprintf("%sREAL8 Percent:=(COUNT(GROUP)/COUNT(%s))*100;\nEND;\n",xyz,dataframe)
			Frequency2 <- hpcc.get.name()
			xyz<-paste(xyz,paste(Frequency2," := TABLE(",OutDSNum,",",FreqRecNum,",field,value,MERGE);"),"\n")  
		}
		
		
		
		if (is.not.null(sortorder))
		{
			if (sortorder=='ASC')
				d<-'+'
			else
				d<-'-'
			
			# 			for (i in 1:length(field_splt[[1]]))
			for (i in 1:1)
				
			{
				
				ind_var<-strim(field_splt[[1]][i])
				if(any(grepl(ind_var,char_new)))
				{
					freq=Frequency1
				}
				else
				{
					freq=Frequency2
				}
				
				dd<-grep(ind_var,split_val[[1]])
				vartype<-strim(split_val[[1]][dd])
				xyz<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(",freq,"(field ='",ind_var,"'),{",vartype,                
									 "STRING value:=value;frequency;Percent}),'",d,ind_var,"');",sep=""),"\n")
			} 
		}
		else
		{
			# 			for (i in 1:length(field_splt[[1]]))
			for (i in 1:1)
				
			{
				ind_var<-strim(field_splt[[1]][i])
				if(any(grepl(ind_var,char_new)))
				{
					freq=Frequency1
				}
				else
				{
					freq=Frequency2
				}
				
				dd<-grep(ind_var,split_val[[1]])
				vartype<-strim(split_val[[1]][dd])
				xyz<-paste(xyz,paste(out.dataframe,":=SORT(TABLE(",freq,"(field ='",ind_var,"'),{",vartype,                
									 "STRING value:=value;frequency;Percent}),'",ind_var,"');",sep=""),"\n")
			}
		}
		hpcc.submit(xyz[1])
		return(out.dataframe)
	}


hpcc.formURL <- function(fileName) {
	url <- paste("http://",hpccHostName,":",hpccPort,"/FileSpray/DownloadFile?Name=",fileName,"&NetAddress=",hpccHostName,"&Path=/var/lib/HPCCSystems/mydropzone/&OS=1",sep='')
	return(url)
}


hpcc.showFilesToDownload <- function() {
	if(length(hpccSessionVariables)<2) {
		print("No Files To download")
		return()
	}
	print('Below are the files available for download')
	for(i in seq(1,length(hpccSessionVariables),by=2)) {
		print(paste(hpccSessionVariables[i],'--',hpccSessionVariables[(i+1)],sep="  "))
		i<-i+1
	}
	a <- TRUE
	while(a) {
		inp <- readline(prompt="Type the number of the file To Download or 0 to exit : ")
		inp <- as.numeric(inp)
		if(inp>0 & inp<=length(hpccSessionVariables)/2) {
			numb <- as.numeric(inp)
			if(hpccSessionVariables[numb,2] %in% hpccDownloadedFiles[,2])
				print('File already downloaded:')
			else {
				nameOfFile <- paste(hpccSessionVariables[numb,2],'.csv',sep='')
				url <- hpcc.formURL(nameOfFile)
				print(url)
				hpcc.downloadFile(url,nameOfFile)
				rbind(hpccDownloadedFiles,c((length(hpccDownloadedFiles)/2)+1,hpccSessionVariables[numb,2]))
			}
			
		}
		else if(inp==0) {
			a <- FALSE
		}
		else
			print('Invalid Input')
	}
}



hpcc.downloadFile <- function(url,fileName) {
	ds <- rawToChar(as.raw(92))
	ds <- sprintf('%s%s',ds,ds)
	sd <- gsub('/',ds,getwd())
	print(sd)
	dest <- paste(sd,rawToChar(as.raw(92)),'rhpcc',rawToChar(as.raw(92)),'downloads',rawToChar(as.raw(92)),'fileName',sep='')
	download.file(url,dest)
	print(paste('File Downloaded at ',dest))
}

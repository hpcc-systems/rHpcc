Begin.Hpcc<-function(signal){
  if (signal=='y' | signal=='Y')
  {
    xyz<<-""
  }  
}


Execute.Hpcc<-function(signal){
  if (signal=='y' | signal=='Y')
  {
    xyz2<<-xyz
    xyz<<-""
    fileout<-getwd()
    str<-.libPaths()
    str1<-paste(str,"/rtoHpcc/hostsetting.txt",sep="")
    tt<-read.table(str1,sep="\t")
    f1<<-as.character(tt$V1[[1]])
    f2<<-as.character(tt$V1[[2]])
    eclCode<<-xyz2
    hostname<<-f1
    port<<-f2
    
    body<-""
    body <-paste('<?xml version="1.0" encoding="utf-8"?>\
                 <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"\ 
                 xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"\ 
                 xmlns="urn:hpccsystems:ws:ecldirect">\
                 <soap:Body>\
                 <RunEclRequest>\
                 <userName>xyz</userName>\
                 <cluster>thor</cluster>\
                 <limitResults>0</limitResults>\
                 <eclText>',eclCode,'</eclText>\
                 <snapshot>test</snapshot>\
                 </RunEclRequest>\
                 </soap:Body>\
                 </soap:Envelope>\n')
    
    headerFields =
      c(Accept = "text/xml",
        Accept = "multipart/*",
        'Content-Type' = "text/xml; charset=utf-8",
        SOAPAction="urn:hpccsystems:ws:ecldirect")
    
    reader = basicTextGatherer()
    handle = getCurlHandle()
    
    ur<-paste("http://",hostname,":",port,"/EclDirect/RunEcl?ver_=1",sep="")
    curlPerform(url = ur,
                httpheader = headerFields,
                postfields = body,
                writefunction = reader$update,
                curl =handle
    )
    status = getCurlInfo( handle )$response.code
    varWu1 <- reader$value()
    newlst<-xmlParse(varWu1)
    layout <- getNodeSet(newlst, "//*[local-name()='results']/text()", namespaces =  xmlNamespaceDefinitions(newlst,simplify = 
                                                                                                               TRUE))    
    colLayout <- layout[[1]]
    layout1<- xmlToList(colLayout)
    contentcsv<<-layout1  
    data <- dataresult(contentcsv, downloadPath=fileout)
  }
  
}


dataresult<-function (xmlResult, downloadPath, format) 
{
  data
  if (missing(xmlResult)) {
    stop("Empty XML String.")
  }
  else {
    docRoot = xmlRoot(xmlTreeParse(contentcsv))
    nodes = getNodeSet(docRoot, "//Dataset")
    
    for (i in 1:length(nodes)) {
      datasetNode <- nodes[[i]]
      
      resultSetName = xmlGetAttr(datasetNode, "name")
      x <- array(1:length(datasetNode) * length(datasetNode[[1]]), 
                 dim = c(length(datasetNode), length(datasetNode[[1]])))
      
      for (j in 1:length(datasetNode)) {
        rowNode <- datasetNode[[j]]
        
        for (k in 1:length(rowNode)) {
          actualNode <- rowNode[[k]]
          x[j, k] <- xmlValue(actualNode)
          
        }
      }
      
      y <- array(1:length(datasetNode) * length(datasetNode[[1]]), 
                 dim = c(length(datasetNode), length(datasetNode[[1]])))      
      for (j in 1:1) {
        rowNode <- datasetNode[[j]]
        
        for (k in 1:length(rowNode)) {
          actualNode <- rowNode[[k]]
          y[j, k] <- xmlName(actualNode)
          
        }
      }
      y1<-y[1,]
      colnames(x, do.NULL = FALSE)
      colnames(x) <- c(y1)
      if (!missing(downloadPath)) {
        if (missing(format)) {
          assign(resultSetName, x,envir = .GlobalEnv)
        }
      }
      data = as.list(data, stringsAsFactors = FALSE)
    }
    data
  }
}


hpccData.layout<-function(logicalfilename,out.struct){
  body<-""
  body <-paste('<?xml version="1.0" encoding="utf-8"?>\
               <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"\ 
               xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/"\ 
               xmlns="urn:hpccsystems:ws:wsdfu">\
               <soap:Body>\
               <DFUInfoRequest>\
               <Name>',logicalfilename,'</Name>\
               </DFUInfoRequest>\
               </soap:Body>\
               </soap:Envelope>\n')
  
  headerFields =
    c(Accept = "text/xml",
      Accept = "multipart/*",
      'Content-Type' = "text/xml; charset=utf-8",
      SOAPAction="urn:hpccsystems:ws:wsdfu")
  
  reader = basicTextGatherer()
  handle = getCurlHandle()
  
  fileout<-getwd()
  str<-.libPaths()
  str1<-paste(str,"/rtoHpcc/hostsetting.txt",sep="")
  tt<-read.table(str1,sep="\t")
  f1<-as.character(tt$V1[[1]])
  f2<-as.character(tt$V1[[2]])
  ur<-paste("http://",f1,":",f2,"/WsDfu?ver_=1.2",sep="")
  curlPerform(url = ur,
              httpheader = headerFields,
              postfields = body,
              writefunction = reader$update,
              curl =handle
  )
  #status = getCurlInfo( handle )$response.code
  
  sResponse <- reader$value()
  responseXml <- xmlParse(sResponse)
  layout <- getNodeSet(responseXml, "//*[local-name()='Ecl']/text()", namespaces =  xmlNamespaceDefinitions(responseXml,simplify = 
                                                                                                              TRUE))
  colLayout <- layout[[1]]
  assign(paste(out.struct),xmlToList(colLayout,addAttributes=TRUE), envir = .GlobalEnv)
}


hpccRead.Data<-function(logicalfilename,layoutname,in.struct,filetype,out.dataframe){
  strim<<-function (x){ 
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)  
  }
  is.not.null <- function(x) ! is.null(x)
  if(missing(logicalfilename))
  {
    stop("no logicalfinlename")   
  }
  else
  {
    xyz<<-""
    strd<-strim(paste(layoutname,":=",in.struct,sep=" "))
    xyz<-strim(paste(strd,sep=""))
    str1<-strim(paste(logicalfilename,"'",sep=""))
    str2<-strim(paste(str1,",",layoutname,",",filetype,");",sep=""))  	
    xyz<-strim(paste(xyz,paste(out.dataframe,":=DATASET('~",str2,sep="")))
    xyz<<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))					
    
  }
}


hpccRead.InlineData<-function(layoutname,linedata,fieldtype,out.dataframe){
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)  
  }
  is.not.null <- function(x) ! is.null(x)
  if(missing(linedata))
  {
    stop("no linedata")	 
  }
  else
  {
    xyz<<-""
    strd<-strim(paste(layoutname,":=RECORD",fieldtype,sep=" "))
    xyz<-strim(paste(strd,"END;",sep=""))		
    str1<-strim(paste(out.dataframe,":=DATASET([",sep=""))
    str2<-strim(paste(linedata))
    str3<-strim(paste(str1,str2,"],",layoutname,");",sep=""))
    str4<-strim(paste(str3,"data_creation",sep=","))	    	
    xyz<-strim(paste(xyz,str3))
    xyz<<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
  }				      			       						
}


hpccSort<-function
(dataframe,fields,out.dataframe,joined=NULL,skew=NULL,threshold=NULL,few=NULL,joinedset=NULL,limit=NULL,target=NULL,size=NULL,local=NULL,stable=NULL,
 unstable=NULL,algorithm=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)  
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe)) {
    stop("no dataframe.")	
  }
  else
  {
    if (is.not.null(joined))
    {	 	
      joinstr<-strim(paste(joined,"(",joinedset,")",sep=""))
    }
    else
    {
      joinstr<-strim(paste(joined,sep=" "))	
    }
    if (is.not.null(skew))
    {
      limt<-strim(paste(limit,target,sep=","))
      skewstr<-strim(paste(skew,"(",limt,")",sep=""))
    }
    else
    { 	 	  			  		
      skewstr<-strim(paste(skew,sep=" "))
    }
    if(is.not.null(threshold))
    {
      threstr<-strim(paste(threshold,"(",size,")",sep=""))
    }
    else
    {
      threstr<-strim(paste(threshold,sep=" "))		
    }
    if(is.not.null(stable))
    {
      stabstr<-strim(paste(stable,"(",algorithm,")",sep=""))
    }
    else
    {
      stabstr<-strim(paste(stable,sep=" "))	
    }
    if(is.not.null(unstable))	
    {
      unstabstr<-strim(paste(unstable,"(",algorithm,")",sep=""))	 	
    }
    else
    {
      unstabstr<-strim(paste(unstable,sep=" "))					
    } 
    str1<-strim(paste(dataframe,fields,joinstr,sep=","))	
    str2<-strim(paste(str1,skewstr,sep=","))
    str3<-strim(paste(str2,threstr,sep=","))
    str4<-strim(paste(str3,stabstr,sep=","))
    str5<-strim(paste(str4,unstabstr,sep=","))
    str6<-strim(paste(str5,local,sep=","))
    str7<-strim(paste(str6,few,sep=","))				
    xyz <- strim(paste(xyz,paste(out.dataframe,":= SORT(",str7,sep="",");")))
    xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
  } 
}



hpccTransform<-function(datastruct=NULL,funcname,parameterlist,skip=NULL,condition=NULL,locals=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)	
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(funcname))
  {
    stop("no funcname")	
  }
  else
  {
    if (is.null(datastruct)) 	
    {
      stru<-strim(paste("MyRec",skip))	  	    	
    }
    else
    {
      stru<-strim(paste(datastruct))		
    }	
    
    if (is.not.null(skip)) 	
    {
      strn1<-strim(paste(":= TRANSFORM,",skip))	  	    	
    }
    else
    {
      strn1<-strim(paste(":= TRANSFORM",skip))		
    }
    
    str1<-strim(paste(stru,funcname,sep=" "))
    str2<-strim(paste(str1,"(",parameterlist,")",sep=""))
    strn2<-strim(paste(strn1,condition,sep=" "))
    xyz <<- strim(paste(xyz,paste(str2,strn2,sep=" ",";END;")))					
    
  }
}



hpccRollup<-function(dataframe,condition=NULL,calltransfunc,out.dataframe,execute=NULL,parallel=NULL,keyed=NULL,local=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)	
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe))
  {
    stop("no dataframe")	
  }
  else
  {   
    strt1<-strim(paste(dataframe,sep=","))
    strt2<-strim(paste(strt1,condition,sep=","))
    nnn<-strim(paste(calltransfunc,"(LEFT,RIGHT)",sep=""))
    strt3<-strim(paste(strt2,nnn,sep=","))
    strt4<-strim(paste(strt3,parallel,sep=","))
    strt5<-strim(paste(strt4,keyed,sep=","))
    strl<-strim(paste(strt5,local,sep=","))
    xyz <- strim(paste(xyz,paste(out.dataframe,":=ROLLUP(",strl,sep="",");")))
    xyz<<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))	
  }
}	


hpccTable<-function
(dataframe,format,out.dataframe,expression=NULL,few=NULL,many=NULL,unsorted=NULL,local=NULL,keyed=NULL,merge=NULL){
  
  strim<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)  
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe)) {
    stop("no dataframe.")  
  }
  else
  {
    if (is.not.null(expression))
    {
      xyz<-NULL
      strexp <- strim(paste(few,many,unsorted,local,keyed,merge,sep=" "))
      strexps <- strim(gsub(' {2,}',' ',strexp))
      str1 <- strim(gsub(' ',',',strexps))
      strexp<-strim(paste(expression))
      str2 <-strim(paste(strexp,str1,sep=","))
      strf<-strim(paste(dataframe,format,str2,sep=","))
      xyz <<- strim(paste(xyz,paste("outdist := TABLE(",strf,sep="",");")))
    }
    else
    {
      xyz<-NULL
      strexp <- strim(paste(few,many,unsorted,local,keyed,merge,sep=" "))
      strexps <- strim(gsub(' {2,}',' ',strexp))
      str1 <- strim(gsub(' ',',',strexps))
      strf<-strim(paste(dataframe,format,str1,sep=","))
      xyz <- strim(paste(xyz,paste(out.dataframe,":= TABLE(",strf,sep="",");")))
      xyz <<-sstrim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
    }
  }
}



hpccDedup<-function(dataframe,out.dataframe,condition=NULL,all=NULL,hash=NULL,keep=NULL,keeper=NULL,local=NULL){
  
  strim<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe)) {
    stop("no dataframe.")	
  }
  else
  {
    if ((is.not.null(all)) & (is.not.null(hash)) & (is.not.null(keep)))
    {
      stop("KEEP is not supported for DEDUP ALL")		 
    }
    else
    {
      if  ((is.not.null(hash)) & (is.not.null(keep)))
      {
        stop("KEEP is not supported for DEDUP ALL")	
      } 
      else
      {
        if  ((is.not.null(all)) & (is.not.null(keep)))			
        {
          stop("KEEP is not supported for DEDUP ALL")		
        }	
        else	
        {
          if((is.null(condition)) & (is.null(all)))
          {
            xyz<-NULL
            strall <- strim(paste(dataframe,condition,"ALL",hash,keeper,local,sep=" "))
            strall1 <- strim(gsub(' {2,}',' ',strall))
            strall2 <- strim(gsub(' ',',',strall1))
            
            strnall <- strim(paste(dataframe,condition,hash,keeper,local,sep=" "))
            strnall1 <- strim(gsub(' {2,}',' ',strnall))
            strnall2 <- strim(gsub(' ',',',strnall1))
            if(is.null(keep))
            {
              strall3 <-strall2
              xyz <<- strim(paste(xyz,paste("outdup := DEDUP(",strall3,sep="",");")))	
            }
            else
            {
              strnall3 <-paste(strnall2,keep,sep=",")
              xyz <<- strim(paste(xyz,paste("outdup := DEDUP(",strnall3,sep="",");")))
            }
          }
          else
          {   			 
            xyz<-NULL
            strall <- strim(paste(dataframe,condition,all,hash,keeper,local,sep=" "))
            strall1 <- strim(gsub(' {2,}',' ',strall))
            strall2 <- strim(gsub(' ',',',strall1))
            
            strnall <- strim(paste(dataframe,condition,hash,keeper,local,sep=" "))
            strnall1 <- strim(gsub(' {2,}',' ',strnall))
            strnall2 <- strim(gsub(' ',',',strnall1))
            
            if(is.null(keep))
            {
              strall3 <-strall2
              xyz <<- strim(paste(xyz,paste("outdup := DEDUP(",strall3,sep="",");")))	
            }
            else
            {
              strnall3 <-paste(strnall2,keep,sep=",")
              xyz <- strim(paste(xyz,paste(out.dataframe,":= DEDUP(",strnall3,sep="",");")))
              xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
            }	   		
          }
        }
      }
    }
  }
}



hpccDistribute<-function
(dataframe,out.dataframe,form=NULL,expression=NULL,index=NULL,skew=NULL,sorts=NULL,joincondition=NULL,maxskew=NULL,skewlimit=NULL)
{
  strim<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
  }   
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe)) {
    stop("no dataframe.")	
  }
  else
  {
    if (is.null(form))
    {
      xyz<-NULL
      strexp <- strim(paste(dataframe,sep=" "))
      xyz <<- strim(paste(xyz,paste("outdist := DISTRIBUTE(",strexp,sep="",");")))
    }
    else
    {
      if (form=='expression')
      {
        if (is.not.null(sorts))
        {
          xyz<-NULL
          strex<-strim(paste("MERGE(",sorts,")",sep=""))
          strexp <- strim(paste(dataframe,expression,strex,sep=","))
          xyz <<- strim(paste(xyz,paste("outdist := DISTRIBUTE(",strexp,sep="",");")))
        }
        else
        {
          xyz<-NULL
          strexp <- strim(paste(dataframe,expression,sep=","))
          xyz <<- strim(paste(xyz,paste("outdist := DISTRIBUTE(",strexp,sep="",");")))
        }
      }
      else
      {
        if (form=='index')
        {
          if (is.not.null(joincondition)) 
          {
            xyz<-NULL	
            strexp <- strim(paste(dataframe,index,joincondition,sep=","))
            xyz <<- strim(paste(xyz,paste("outdist := DISTRIBUTE(",strexp,sep="",");")))
          }
          else
          {
            xyz<-NULL	
            strexp <- strim(paste(dataframe,index,sep=","))
            xyz <<- strim(paste(xyz,paste("outdist := DISTRIBUTE(",strexp,sep="",");")))
          }
        } 		
        else
        {
          if (form=='skew')
          {
            xyz<-NULL
            stre<-strim(paste(maxskew,skewlimit,sep=" "))
            stre1<-strim(gsub(' {2,}',' ',stre))
            stre2<-strim(gsub(' ',',',stre1))
            strex<-strim(paste("SKEW(",stre2,")",sep=""))
            strexp <- strim(paste(dataframe,strex,sep=","))
            xyz <- strim(paste(xyz,paste(out.dataframe,":= DISTRIBUTE(",strexp,sep="",");")))
            xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
          }
        }
      }	
    }
  }
}



hpccIterate<-function(dataframe,calltransfunc,out.dataframe,local=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)	
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe))
  {
    stop("no dataframe.")	
  }
  else
  {	
    strt1<-strim(paste(dataframe,sep=""))
    strt2<-strim(paste(calltransfunc,"(LEFT,RIGHT)",sep=""))
    strt3<-strim(paste(strt1,strt2,sep=","))
    strl<-strim(paste(strt3,local,sep=","))
    xyz <- strim(paste(xyz,paste(out.dataframe,":=ITERATE(",strl,sep="",");")))
    xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))	
  }		
}	


hpccNewlayout<-function(layoutname,prelayout=NULL,newVarType=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)	
  }
  is.not.null <- function(x) ! is.null(x)
  if (missing(layoutname))
  {
    stop("no layoutname.")	
  }
  else
  {
    if (is.not.null(prelayout))
    {
      strt2<-strim(paste(prelayout,";",sep=""))
    }
    else
    {
      strt2<-strim(paste(prelayout,sep=""))
    }
    strt1<-strim(paste(layoutname,":=RECORD ",sep=""))
    strt3<-strim(paste(newVarType,"END;",sep=""))
    xyz<<-strim(paste(xyz,paste(strt1,strt2,strt3,sep="")))
  }		
}	





hpccProject<-function
(dataframe,calltransfunc,counter=NULL,out.dataframe,prefetch=NULL,lookahead=NULL,parallel=NULL,keyed=NULL,local=NULL){
  
  strim<<-function (x) 
  {
    gsub("^\\s+|\\s+$", "", x)
    gsub("^,+|,+$", "", x)	
  }
  
  is.not.null <- function(x) ! is.null(x)
  if (missing(dataframe))
  {
    stop("no dataframe.")	
  }
  else
  {
    
    strt1<-strim(paste(dataframe,sep=""))
    strt2<-strim(paste(calltransfunc,"(LEFT,",counter,sep=""))
    strt3<-strim(paste(strt1,strt2,")",sep=","))
    strt4<-strim(paste(strt3,prefetch,sep=","))
    strt5<-strim(paste(strt4,lookahead,sep=","))
    strt6<-strim(paste(strt5,parallel,sep=","))
    strt7<-strim(paste(strt6,keyed,sep=","))
    strl<-strim(paste(strt7,local,sep=","))
    xyz <- strim(paste(xyz,paste(out.dataframe,":=PROJECT(",strl,sep="",");")))	
    xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
  }		
}	



hpccMin<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe) 
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {   
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }	
    
  }
  
  xyz<<-paste(xyz,paste("recmin :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recmin mintrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRMIN:=PROJECT(",dataframe,",mintrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSR;"),"\n")
  xyz<<-paste(xyz,paste("NumField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMin:=NORMALIZE(DSRMIN,",length(varlst[[1]]),",TRANSFORM(NumField,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsMin;"),"\n")
  xyz<<-paste(xyz,paste("SingleField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDSMin.Field;"),"\n")
  xyz<<-paste(xyz,paste("Minval := MIN(GROUP,OutDSMin.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDSMin,SingleField,Field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
}


hpccMax<-function(dataframe,fields,out.dataframe){
  
  trim<-function (dataframe) 
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {   
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }	
    
  }
  
  xyz<<-paste(xyz,paste("recmax :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("RECMAX maxtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRMAX:=PROJECT(",dataframe,",maxtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRMAX;"),"\n")
  xyz<<-paste(xyz,paste("MaxField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING Field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsMax:=NORMALIZE(DSRMAX,",length(varlst[[1]]),",TRANSFORM(MaxField,SELF.id:=LEFT.id,SELF.Field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsMax;"),"\n")
  xyz<<-paste(xyz,paste("SinglemaxField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsMax.Field;"),"\n")
  xyz<<-paste(xyz,paste("Maxval   := MAX(GROUP,OutDsMax.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsMax,SinglemaxField,Field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
}



hpccMean<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe) 
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {   
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }	
    
  }
  
  xyz<<-paste(xyz,paste("recavg :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recavg avgtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRAVG:=PROJECT(",dataframe,",avgtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRAVG;"),"\n")
  xyz<<-paste(xyz,paste("NumAvgField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsavg:=NORMALIZE(DSRAVG,",length(varlst[[1]]),",TRANSFORM
                        (NumAvgField,SELF.id:=LEFT.id,SELF.field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsavg;"),"\n")
  xyz<<-paste(xyz,paste("SingleavgField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsavg.field;"),"\n")
  xyz<<-paste(xyz,paste("Mean   := AVE(GROUP,OutDsavg.value);"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsavg,SingleavgField,field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
}	




hpccSd<-function(dataframe,fields,out.dataframe){
  
  strim<-function (dataframe) 
  {
    gsub("^\\s+|\\s+$", "", dataframe)
  }
  
  varlst<<-strsplit(fields, ",")
  str1<-NULL
  str2<-NULL
  for (i in 1:length(varlst[[1]]))
  {
    k<-strim(varlst[[1]][i])
    h<<-strsplit(k," ")
    if (i > 1)
    {
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh,sep=","))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh,sep=","))
    }
    else
    {   
      charh<-paste("'",h[[1]][1],"'",sep="")
      str1<-strim(paste(str1,charh))
      hh<-strim(paste("LEFT.",h[[1]][1],sep=""))
      str2<-strim(paste(str2,hh))
    }	
    
  }	
  xyz<<-paste(xyz,paste("recsd :=RECORD"),"\n")
  xyz<<-paste(xyz,paste("INTEGER3 id;"),"\n")
  xyz<<-paste(xyz,paste(dataframe,";"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("recsd sdtrans (",dataframe," L, INTEGER C) := TRANSFORM"),"\n")
  xyz<<-paste(xyz,paste("SELF.id :=C;"),"\n")
  xyz<<-paste(xyz,paste("SELF :=L;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("DSRSD:=PROJECT(",dataframe,",sdtrans(LEFT,COUNTER));"),"\n")
  #xyz<<-paste(xyz,paste("DSRSD;"),"\n")
  xyz<<-paste(xyz,paste("NumSdField:=RECORD"),"\n")
  xyz<<-paste(xyz,paste("UNSIGNED id;"),"\n")
  xyz<<-paste(xyz,paste("STRING field;"),"\n")
  xyz<<-paste(xyz,paste("REAL8 value;"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste("OutDsSd:=NORMALIZE(DSRSD,",length(varlst[[1]]),",TRANSFORM(NumSdField,SELF.id:=LEFT.id,SELF.field:=CHOOSE
                        (COUNTER,",str1,sep="",");SELF.value:=CHOOSE(COUNTER,",str2,")));","\n"))
  #xyz<<-paste(xyz,paste("OutDsSd;"),"\n")
  xyz<<-paste(xyz,paste("SingleSdField := RECORD"),"\n")
  xyz<<-paste(xyz,paste("OutDsSd.field;"),"\n")
  xyz<<-paste(xyz,paste("Sd   := SQRT(VARIANCE(GROUP,OutDsSd.value));"),"\n")
  xyz<<-paste(xyz,paste("END;"),"\n")
  xyz<<-paste(xyz,paste(out.dataframe,":= TABLE(OutDsSd,SingleSdField,field);"),"\n")
  xyz <<-strim(paste(xyz,paste("OUTPUT(",out.dataframe,",named('",out.dataframe,"'));",sep="")))
}	
